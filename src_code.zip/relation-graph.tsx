/**
 * ============================================================
 * 原石航路 Studio
 * RelationGraph — 関係を図にする
 *
 * 物理演算は使わない。円周上に決まった順で並べる。
 * 開くたびに配置が変わると、前に見たときの記憶が使えなくなる。
 * 項目の並び順が同じなら、図もいつも同じ形になる。
 * ============================================================
 */

"use client";

import { useEffect, useRef, useState } from "react";

import { getImage } from "@/lib/storage/image-store";

import type { ResourceEntry, ResourceRelation } from "@/types";

interface Props {
    entries: ResourceEntry[];
    relations: ResourceRelation[];
    onSelect: (entryId: string | null) => void;
    selectedId: string | null;
    /**
     * 置いた場所。項目の id から座標を引く。
     * 覚えていないと、開き直すたびに円周へ戻ってしまう。
     */
    layout?: Record<string, { x: number; y: number }>;
    onMove?: (entryId: string, position: { x: number; y: number }) => void;
    /** 置いた場所を捨てて、円周の並びに戻す */
    onReset?: () => void;
    /**
     * 線の中間点を動かしたとき。
     *
     * null を渡すと、これまでどおりの曲げ方に戻る。
     */
    onBend?: (relationId: string, bend: { x: number; y: number } | null) => void;
}

/** 図の広さ。もとの大きさ。広げるときは、これに倍率を掛ける */
const BASE_SIZE = 400;

/*
 * 板の横と縦の比。
 *
 * ★ 横長にする。
 *
 *   前は正方形だった。枠は横に長いので、
 *   正方形の図を入れると左右が大きく空く。
 *   その空きぶん、図は縦に合わせて縮み、
 *   文字が小さくなっていた。
 *
 *   枠と同じ形にすれば、空きが減り、
 *   同じ枠でも大きく描ける。
 */
const ASPECT = 1.6;

/*
 * 紙の外側の余白。
 *
 * ★ 0 にする。
 *
 *   余白を足すと、描く範囲の比が紙の比とずれる。
 *   いちばん小さくしたときに、上下か左右が必ず余る。
 *   「紙が枠にぴったり」にならない。
 *
 *   端に置いた丸が切れないようにするのは、
 *   丸を置ける範囲（EDGE）のほうで受け持つ。
 */
const PAD = 0;

/*
 * 紐の長さ。丸どうしの離れ具合。
 *
 * 板の大きさは、この値で決まる。
 * 図の外でも使うので、部品の外に置く。
 */
/*
 * ★ 紙は、枠よりずっと広く取る。
 *
 *   つまみを小さくすると、その広い紙の全体が
 *   枠の中に小さく見える。丸は隅々まで置ける。
 *
 *   つまみを大きくすると、紙の一部が
 *   枠いっぱいに拡大され、送って見る。
 *
 *   前は 1.5（960×600）で、枠とほぼ同じ広さだった。
 *   だから小さくしても、置ける範囲が広がらなかった。
 *
 *   4.0 なら 2560×1600。枠のおよそ 2.7 倍の広さ。
 */
/*
 * ★ 紙の広さは、つまみで決める。
 *
 *   人が増えるほど窮屈になるので、
 *   広い紙を使えるようにする。
 *
 *   ここに書いてあるのは、いちばん狭いときの値。
 *   広げるときは、これに倍率を掛ける。
 */
const SPREAD = 2.5;

/* 紙の形。広さが変わっても、形は変わらない */
const DRAWN_ASPECT = ASPECT;
const BASE_RADIUS = 142;

/*
 * 丸どうしの、いちばん近い間。
 *
 * ★ 丸の直径に、名前のぶんを足す。
 *   名前は丸の下に出るので、縦に重なりやすい。
 */
const MIN_GAP = 140;
/*
 * 丸の大きさ。
 * 頭文字が読める大きさにする。小さいと点にしか見えない。
 */
/*
 * ★ 紙を広げたぶん、丸と字も大きくする。
 *
 *   紙は 2560×1600。枠に全体を収めると 0.6 倍ほどに縮む。
 *   丸の半径 21 は画面で 13px、字の 14 は 8.6px。
 *   小さすぎて読めない。
 *
 *   1.7 倍にしておけば、全体を見たときに
 *   丸 22px、字 15px ほどになる。
 */
const NODE_RADIUS = 36;

/** 関係の名前から線の色を決める。同じ名前なら同じ色になる */
const RELATION_COLORS = [
    "#2f6b3d", "#3a5a7d", "#7d4a3a", "#5a4a7d",
    "#7d6b3a", "#3a7d75", "#6b3a5a", "#4a5a3a",
];

/*
 * ============================================================
 * 関係の色は、6 つにまとめる
 *
 * ★ 47 種類を 47 色にしても、人は覚えられない。
 *
 *   前は関係の名前ごとに違う色を振っていた。
 *   色の数だけ凡例が並び、図そのものより
 *   下の帯のほうが賑やかになっていた。
 *
 *   色で分けるのは「どういう間柄か」の大枠だけにする。
 *   細かい名前は、線に触れたときに出す。
 *
 * ★ 6 つにしたのは、一目で覚えられる数だから。
 *   これ以上増やすと、また覚えられなくなる。
 *
 * ★ どれにも当てはまらないものは「その他」。
 *   作者が自分で付けた名前は、そこへ入る。
 * ============================================================
 */
export const RELATION_GROUPS: {
    key: string;
    label: string;
    color: string;
    words: string[];
}[] = [
    {
        key: "family",
        label: "家族・恋愛",
        color: "#d9738f",
        words: [
            "兄弟", "姉妹", "家族", "夫婦", "片想い", "片思い", "許嫁",
            "息子", "娘", "祖父", "祖母", "叔父", "叔母", "伯父", "伯母",
            "従兄", "従弟", "従姉", "従妹", "親子", "義理",
            "父", "母", "兄", "弟", "姉", "妹", "親", "子", "祖",
            "恋", "婚", "想い", "血縁",
        ],
    },
    {
        key: "friend",
        label: "友好",
        color: "#3f9a7a",
        words: [
            "親友", "友人の友人", "クラスメイト", "知り合い", "知人",
            "仲間", "同級", "同期", "相棒", "味方", "協力", "協定",
            "同盟", "推し", "庇護", "恩人", "友",
        ],
    },
    {
        key: "enemy",
        label: "敵対",
        color: "#c4453a",
        words: [
            "敵", "対立", "宿敵", "仇", "復讐", "憎", "苦手", "不信",
            "襲撃", "殺", "裏切", "ライバル", "競",
        ],
    },
    {
        key: "belong",
        label: "所属・仕事",
        color: "#3a6ea8",
        words: [
            "従者", "部下", "上司", "同僚", "所属", "眷属", "奴隷",
            "使役", "手駒", "器物", "利用", "雇", "仕事", "取引", "臣",
            "主従", "駒",
        ],
    },
    {
        key: "master",
        label: "師弟",
        color: "#b5852f",
        words: ["師弟", "師匠", "弟子", "先輩", "後輩", "教え子", "指導", "門下", "師"],
    },
    {
        key: "other",
        label: "その他",
        color: "#8a8f93",
        words: [],
    },
];

/*
 * 言葉と大枠の対応。長いものから先に見る。
 *
 * ★ 短い言葉から当てると、取り違える。
 *
 *   「師弟」は「弟」に当たって家族になり、
 *   「親友」は「親」に当たって家族になっていた。
 *   「従者」も「従（従兄弟）」に当たっていた。
 *
 *   長い言葉を先に見れば、
 *   師弟・親友・従者のほうが先に当たる。
 */
const GROUP_WORDS = RELATION_GROUPS.flatMap((group) =>
    group.words.map((word) => ({ word, group })),
).sort((a, b) => b.word.length - a.word.length);

/** その関係が、どの大枠に入るか */
export function groupOf(label: string) {
    const text = label.trim();

    for (const one of GROUP_WORDS) {
        if (text.includes(one.word)) return one.group;
    }

    return RELATION_GROUPS[RELATION_GROUPS.length - 1];
}

function colorOf(label: string): string {
    return groupOf(label).color;
}

interface Dragging {
    id: string;
    position: { x: number; y: number };
    /** 押した場所と丸の中心のずれ。掴んだ位置を保ったまま動かすため */
    offset: { x: number; y: number };
    moved: boolean;
}

export default function RelationGraph({
    entries,
    relations,
    onSelect,
    selectedId,
    layout = {},
    onMove,
    onReset,
    onBend,
}: Props) {
    const [hoveredId, setHoveredId] = useState<string | null>(null);

    /*
     * いま、どの線の中間点をつまんでいるか。
     *
     * ★ 丸を動かすのとは、別に持つ。
     *   同じ入れ物にすると、どちらを動かしているのか
     *   分からなくなる。
     */
    /*
     * 中間点を出している線。
     *
     * 線を二度押すと出る。もう一度押すと引っ込む。
     */
    /* 名前で探すときの、打った字 */
    const [findText, setFindText] = useState("");

    const [openBendId, setOpenBendId] = useState<string | null>(null);

    const [bending, setBending] = useState<{
        id: string;
        position: { x: number; y: number };
    } | null>(null);

    /*
     * その人を中心に見るか。
     *
     * ★ 初めは入れない。
     *
     *   入れて出していたが、丸を押した瞬間に
     *   その人が中心へ据え直され、掴んで動かせなくなった。
     *   並びをこちらが決めている間は、動かしても残らないため。
     *
     *   「真ん中以外動かせない」という声は、これ。
     *
     *   ふだんは、押したら選ぶだけ。動かせる。
     *   中心に見たい人が、押し具で切り替える。
     */
    const [isFocusMode, setIsFocusMode] = useState(false);

    /*
     * いま見ている章。null は全部の時点。
     *
     * ★ 小説の関係は、話が進むと変わる。
     *
     *   最初は敵、途中で協力、最後は仲間。
     *   全部を一枚に重ねると、
     *   「3章の時点では誰と誰が知り合いだったか」が分からない。
     *
     * ★ 登場する章を決めていない人は、どの章でも出る。
     *   入れた人だけが絞られる。
     */
    const [chapter, setChapter] = useState<number | null>(null);

    /*
     * この作品で使われている章。
     *
     * 誰かが入れている章だけを並べる。
     * 1 から順に全部出すと、使っていない章まで押せてしまう。
     */
    const allChapters = Array.from(
        new Set(entries.flatMap((entry) => entry.chapters ?? [])),
    ).sort((a, b) => a - b);

    /*
     * 図の大きさ。
     *
     * ★ 枠にぴったり収まる大きさを 50% とする。
     *
     *   いまの見え方が 50%。そこから大きくも小さくもできる。
     *   50 より上にすると枠からはみ出すので、送って見る。
     *   50 以下なら、送らずに全体が見える。
     *
     * ★ 広さとは別のもの。
     *
     *   広さ  丸と丸の間の空き方（並べ方）
     *   大きさ 描かれるものの大きさ（見え方）
     *
     *   項目が多いときは、広さを広げて大きさを下げると
     *   全体が見える。近くを読みたいときは大きさを上げる。
     */
    /*
     * 図の大きさ。
     *
     * ★ いつも枠ぴったり。選ばせない。
     *
     *   前は 25〜100% から選べて、画面いっぱいにも広げられた。
     *   押し具が 2 段になり、どれを触ればよいのか分からない。
     *
     *   紐の長さを変えれば、詰まり具合は調えられる。
     *   大きさまで持たせる必要がなかった。
     */
    /*
     * 大きさ。つまみ 1 つで決める。
     *
     * ★ 0 で丸が小さく、100 で大きい。
     *
     *   中では「紐の長さ」を動かしている。
     *   図は枠いっぱいに縮めて描くので、
     *   紐を長くすると全体が縮み、丸が小さくなる。
     *   短くすると丸が大きくなる。
     *
     *   押し具を 2 段に分けていたが、
     *   触る人にとっては「大きさ」ひとつで足りる。
     *
     * ★ 図はいつも枠ぴったり。送りは出ない。
     */




    /*
     * 紐の長さ。
     *
     * ★ 丸と丸を、どれだけ離して並べるか。
     *
     *   離すほど紐は長くなり、どこへ繋がっているか
     *   目で追いやすい。近いほど図はまとまるが、
     *   紐が束になって読めなくなる。
     *
     * ★ 見え方の大きさとは別。
     *
     *   紐の長さ  並べ方。丸どうしの離れ具合
     *   大きさ    見え方。枠の中でどれだけ大きく描くか
     *
     * ★ 数字を変えると、置いた場所が合わなくなる。
     *   座標は、この広さの中の位置として控えてある。
     *   短くすると、外にあった丸が端に貼り付く。
     *   そのときは「整理する」で並べ直してもらう。
     */
    /*
     * ★ 初めは「ふつう」。
     *
     *   長くするほど図は広がるが、枠に収めるぶん
     *   全部が縮んで名前が読めなくなる。
     *   まず読める大きさから始めて、
     *   足りなければ伸ばしてもらう。
     */
    /*
     * つまみの値。0〜100。
     *
     * ★ 右へ動かすほど、丸が大きい。
     *
     *   中では紐の長さを動かしている。
     *   紐が短いほど図が詰まり、枠に収めたときに丸が大きくなる。
     *   つまり、つまみと紐の長さは逆向き。
     */
    /*
     * 大きさ。0〜100。
     *
     * ★ 大きな一枚を、拡げたり縮めたりして見る。
     *
     *   前は「枠にぴったり収める」作りだった。
     *   人が増えるほど全体が縮み、名前が読めなくなる。
     *
     *   一枚の大きさを変えられるようにして、
     *   見たいところへ送って見てもらう。
     *
     * ★ 初めは、いちばん大きい。
     *   小さく出して「読めない」と思われるより、
     *   大きく出して「送れば見える」ほうがよい。
     */
    /*
     * ★ 初めは、枠ぴったり。
     *   つまみの 38 あたりで 1.0 倍になる。
     */
    /*
     * ★ 初めは、枠ぴったり。
     *
     *   つまみの真ん中が 1.0 倍。
     *   左端で 0.35 倍、右端で 1.9 倍。
     *
     *   前は右半分で大きくならなかった。
     *   板の外まで描こうとしていたので、
     *   はみ出したぶんが切れていた。
     */
    /*
     * ★ 初めは、紙が枠ぴったりのところ。
     *   そこから、引いて眺めるか、寄って読むか。
     */
    /*
     * 紙の広さ。0〜100。
     *
     * ★ つまみは 1 つで足りる。
     *
     *   紙を広げると、枠に収めるぶん見かけが縮む。
     *   狭めると、枠に収まらず送って見ることになる。
     *   これは拡大・縮小と同じことをしている。
     *
     *   前は「広さ」と「拡大」の 2 つを並べていたが、
     *   触る人からは同じ動きに見える。
     *
     * ★ 右へ動かすほど、広い紙。
     *
     *   100 いちばん広い。全体が枠に収まり、小さく見える
     *   0   狭い紙。丸が詰まり、送って見る
     */
    const [wideValue, setWideValue] = useState(100);

    /*
     * 送る枠。
     *
     * 大きさを変えたとき、真ん中が見えるように寄せ直す。
     */
    const panRef = useRef<HTMLDivElement>(null);

    /*
     * 枠の高さ。図の大きさを、実寸で出すのに使う。
     *
     * 割合で指定すると、入れ物の作りによって
     * 伸びたり伸びなかったりする。
     */
    const [box, setBox] = useState({ w: 0, h: 0 });

    /*
     * 枠にちょうど収まる高さ。
     *
     * 板は横長なので、枠の形によっては
     * 横が先に足りなくなる。両方を見て、小さいほうに合わせる。
     */
    /*
     * 紙の形を、枠に合わせる。
     *
     * ★ 形が違うと、必ず余白が出る。
     *
     *   紙を 1.6 で固定していた。枠の形は画面によって
     *   1.4 のことも 1.8 のこともある。
     *   収めたときに、上下か左右が必ず余っていた。
     *
     *   枠と同じ形にすれば、ぴったり収まる。
     *   余白が消えて、そのぶん広く使える。
     *
     * ★ 測れていないあいだは、1.6 のまま。
     */
    const liveAspect = box.w && box.h ? box.w / box.h : DRAWN_ASPECT;

    const fitHeight = box.h || 0;

    /*
     * つまみから、倍率を出す。
     *
     * ★ 紙は一枚。広さは変わらない。つまみは倍率だけ。
     *
     *   0   紙の全体を、遠くから眺める。
     *       枠のまわりに余白が出るが、形は掴める。
     *
     *   39  紙が枠にぴったり。
     *
     *   100 紙の一部が、枠いっぱいに拡大される。
     *       見たいところへ送って見る。
     *
     * ★ 余白の外へは、丸を置けない。
     *   そこは紙ではないので。
     *   紙の端までは行ける（壁は丸の縁ぶんだけ）。
     *
     * ★ 掛け算で伸ばす。
     *   足し算だと、小さいほうの差が目盛りに出ない。
     */
    /* 紙の広さの倍率。1.0 〜 3.0 */
    const wide = 1 + (wideValue / 100) * 2;

    /*
     * 枠に対する、描く大きさ。
     *
     * ★ いちばん広い紙のときに、ちょうど枠に収まる。
     *   狭めると、そのぶん丸が大きく見え、枠からはみ出す。
     *
     *   紙が狭い ＝ 同じ丸が詰まっている ＝ 拡大して見ている
     *   ということ。別のつまみは要らない。
     */
    const scale = 3 / wide;

    useEffect(() => {
        const el = panRef.current;
        if (!el) return;

        /*
         * ★ 少しだけ小さく測る。
         *
         *   ぴったりに合わせると、端数の丸めで
         *   1 ピクセルはみ出すことがある。
         *   はみ出すと送りが出て、そのぶん幅が減り、
         *   またはみ出す——という堂々巡りになる。
         *
         *   2 ピクセル譲っておけば、そうならない。
         */
        const measure = () =>
            setBox({
                w: Math.max(0, el.clientWidth - 2),
                h: Math.max(0, el.clientHeight - 2),
            });
        measure();

        const watcher =
            typeof ResizeObserver !== "undefined"
                ? new ResizeObserver(measure)
                : null;
        watcher?.observe(el);

        return () => watcher?.disconnect();
    }, []);

    useEffect(() => {
        const box = panRef.current;
        if (!box) return;

        /* 描き直したあとに寄せる */
        const timer = window.setTimeout(() => {
            box.scrollLeft = (box.scrollWidth - box.clientWidth) / 2;
            box.scrollTop = (box.scrollHeight - box.clientHeight) / 2;
        }, 30);

        return () => window.clearTimeout(timer);
    }, [wideValue]);


    /*
     * 画面いっぱいに広げるか。
     *
     * ★ 枠は頁の一部なので、どうしても小さい。
     *   人が増えると、名前が読める大きさにならない。
     *
     * ★ 広げるのは器だけ。図の作りは変えない。
     * ★ Esc で閉じる。押し具だけだと、逃げ場が無い。
     */
    const [isFull, setIsFull] = useState(false);

    useEffect(() => {
        if (!isFull) return;

        function onKey(event: KeyboardEvent) {
            if (event.key === "Escape") setIsFull(false);
        }

        document.addEventListener("keydown", onKey);
        /* 後ろの頁が動くと、どこを見ていたか分からなくなる */
        document.body.style.overflow = "hidden";

        return () => {
            document.removeEventListener("keydown", onKey);
            document.body.style.overflow = "";
        };
    }, [isFull]);

    /*
     * 紐の長さ。
     *
     * ★ 決め打ちにする。
     *
     *   つまみは一枚の大きさを変えるためのもので、
     *   丸どうしの離れ具合とは別の話。
     *   両方をひとつのつまみで動かすと、
     *   何が起きているのか分からない。
     *
     *   離れ具合を変えたいときは「整理する」。
     */
    const spread = SPREAD * wide;
    /*
     * 板の大きさ。
     *
     * ★ 縦は今までどおり。横だけ広げる。
     *   縦を変えると、置いた場所が縦にずれる。
     *   横に広げるぶんには、右に余地ができるだけで
     *   すでに置いた丸は動かない。
     */
    /*
     * 紙の高さ。
     *
     * ★ 広さのつまみで決まる。
     *   輪が収まるだけの広さがあればよい。
     */
    const HEIGHT = Math.round(BASE_SIZE * spread);
    /* 紙の横幅。枠と同じ形にする */
    const WIDTH = Math.round(HEIGHT * liveAspect);
    const CENTER_X = WIDTH / 2;
    const CENTER_Y = HEIGHT / 2;
    /*
     * 丸を並べる輪の大きさ。
     *
     * ★ 紙いっぱいに広げる。
     *
     *   前は紙の 7 割ほどの輪だった。
     *   左右に 139、上下に 87 の余りが出て、
     *   端のほうへは自分で運ばないと届かない。
     *   「左右上下に行けない」と見えるのは、これ。
     *
     *   丸と名前が切れない幅だけ残して、あとは使う。
     */

    const [dragging, setDragging] = useState<Dragging | null>(null);
    const svgRef = useRef<SVGSVGElement>(null);

    /*
     * 図に出す人。
     *
     * ★ まだ結んでいない人も出す。
     *
     *   前は関係を持つ人だけを出していた。
     *   11 人いるのに 4 人しか出ず、
     *   「誰をまだ結んでいないか」が分からなかった。
     *
     *   全体像を見る場所なので、全員が居るべき。
     *
     * ★ ただし薄く、外側に置く。
     *   結んである人の図を、邪魔しないように。
     */
    const connectedIds = new Set<string>();
    for (const relation of relations) {
        connectedIds.add(relation.from_entry_id);
        connectedIds.add(relation.to_entry_id);
    }

    /*
     * ★ まだ結んでいない人は、図に出さない。
     *
     *   一度出してみたが、数百並んで図が埋まった。
     *   本文から拾った断片まで項目として入っているため。
     *
     *   全部を出すのは、項目が整っている作品でしか成り立たない。
     *   ここは関係を見る場所であって、
     *   まだ結んでいない人を数える場所ではない。
     */
    const nodes = entries.filter((entry) => connectedIds.has(entry.id));

    /*
     * 初めに並ぶ輪の大きさ。
     *
     * ★ 人数で決める。紙の広さでは決めない。
     *
     *   紙を広げたら、そのぶん輪も広がっていた。
     *   4 人しかいないのに四隅へ散らばり、
     *   線だけがやたら長くなる。
     *
     *   輪の長さは「人数 × 丸どうしの間」で足りる。
     *   それ以上広げても、間が空くだけで読みにくい。
     *
     * ★ 紙からはみ出さないよう、上限だけ紙で決める。
     */
    const EDGE = NODE_RADIUS + 34;

    const MAX_X = WIDTH / 2 - EDGE;
    const MAX_Y = HEIGHT / 2 - EDGE;

    /*
     * 人数ぶんの丸が、間を空けて並ぶのに要る半径。
     *
     * ★ 一人あたり、丸の直径の 3 倍ほどを見込む。
     *
     *   MIN_GAP（丸どうしの最短の間）で数えると、
     *   4 人のときに輪が丸 2 個ぶんしかなく、
     *   団子になってしまう。
     *
     * ★ 少なくても、丸 5 個ぶんの輪は取る。
     *   2 人や 3 人のときに、くっつきすぎないように。
     */
    /*
     * 初めに並ぶ輪の大きさ。
     *
     * ★ 紙いっぱいに広げる。
     *
     *   自分で置いた丸は動かさないが、
     *   まだ置いていない丸は、紙の広さに合わせて並べる。
     *
     *   合わせないと、紙を広げたときに
     *   丸だけ左上に取り残され、右下が空になる。
     *
     * ★ 人数ぶんの下限も見る。
     *   人が少ないときに、四隅へ散らばりすぎないように。
     */
    const PER_NODE = NODE_RADIUS * 6;
    const NEEDED = Math.max(
        NODE_RADIUS * 5,
        (nodes.length * PER_NODE) / (Math.PI * 2),
        MAX_Y * 0.95,
    );

    const RADIUS_Y = Math.min(MAX_Y, NEEDED);
    const RADIUS_X = Math.min(MAX_X, RADIUS_Y * liveAspect);


    /*
     * 丸の中に出す絵。
     *
     * ★ image_url は、そのままでは絵の住所ではない。
     *
     *   「idb:…」の形で覚えていることがあり、
     *   そのときは置き場から引き出さないと出せない。
     *   一覧では EntryImage が同じことをしている。
     *   ここだけ生のまま <image> に渡していたので、丸が空だった。
     */
    const [pictures, setPictures] = useState<Record<string, string>>({});

    useEffect(() => {
        let isAlive = true;

        void (async () => {
            const found: Record<string, string> = {};

            await Promise.all(
                entries
                    .filter((entry) => entry.image_url)
                    .map(async (entry) => {
                        try {
                            const value = await getImage(entry.image_url as string);
                            if (value) found[entry.id] = value;
                        } catch {
                            /* 引き出せない絵は、丸のまま出す */
                        }
                    }),
            );

            if (isAlive) setPictures(found);
        })();

        return () => {
            isAlive = false;
        };
    }, [entries]);

    if (nodes.length === 0) {
        return (
            <div className="flex h-40 items-center justify-center rounded-md border border-dashed border-line">
                <p className="text-sm text-faint">
                    関係を結ぶと、ここに図が出ます。
                </p>
            </div>
        );
    }

    /*
     * ============================================================
     * その人を中心に見る
     *
     * ★ 選んだ人と、直につながる人だけを残す。
     *
     *   47 人を薄くして残しても、地は埋まったまま。
     *   関わりのない人は、出さない。
     *
     * ★ 選んだ人を真ん中に置き、まわりに輪で並べる。
     *
     *   置いた場所をそのまま使うと、
     *   選んだ人が端にいたとき、輪が画面の外へ出る。
     *   中心に据え直せば、何人いても収まる。
     *
     * ★ 元の並びは壊さない。
     *   ここで作るのは、見せ方だけ。
     *   置いた場所は表に残したまま。
     * ============================================================
     */
    /*
     * その章に出る人か。
     *
     * 決めていない（空）人は、どの章でも出る。
     * 決めていない人まで消すと、
     * 何も入力していない作品では図が空になる。
     */
    function inChapter(node: { chapters?: number[] | null }) {
        if (chapter === null) return true;
        const list = node.chapters;
        if (!list || list.length === 0) return true;
        return list.includes(chapter);
    }

    const focusId = isFocusMode ? selectedId : null;

    /** 選んだ人と、直につながる人 */
    const focusIds = (() => {
        if (!focusId) return null;

        const near = new Set<string>([focusId]);
        for (const relation of relations) {
            if (relation.from_entry_id === focusId) near.add(relation.to_entry_id);
            if (relation.to_entry_id === focusId) near.add(relation.from_entry_id);
        }
        return near;
    })();

    /* 出す人。章で絞り、中心に見るときは近い人だけ */
    const inChapterNodes = nodes.filter(inChapter);
    const shownNodes = focusIds
        ? inChapterNodes.filter((node) => focusIds.has(node.id))
        : inChapterNodes;

    const shownIds = new Set(shownNodes.map((node) => node.id));

    /*
     * 出す線。
     *
     * ★ 両端とも出ている人でなければ、線も出さない。
     *   片方が消えている線は、どこへも繋がらない。
     */
    const shownRelations = relations.filter((relation) => {
        if (!shownIds.has(relation.from_entry_id)) return false;
        if (!shownIds.has(relation.to_entry_id)) return false;

        if (focusId) {
            return (
                relation.from_entry_id === focusId ||
                relation.to_entry_id === focusId
            );
        }
        return true;
    });

    /*
     * 覚えている位置を、いまの紙に収める倍率。
     *
     * ★ 紙の広さや丸の大きさを変えると、
     *   昔の位置が紙からはみ出す。
     *   はみ出したところは描かれないので、
     *   丸が消えたように見える。
     *
     * ★ 端に貼り付けるのではなく、まとめて縮める。
     *   貼り付けると、並びが潰れて重なる。
     *   同じ割合で縮めれば、形は保たれる。
     */


    const positions = new Map<string, { x: number; y: number }>();

    if (focusId && focusIds) {
        /* 真ん中に、選んだ人 */
        positions.set(focusId, { x: CENTER_X, y: CENTER_Y });

        const around = shownNodes.filter((node) => node.id !== focusId);

        /*
         * まわりの輪。
         *
         * 人数が少ないときは小さく、多いときは大きく。
         * いつも同じ大きさだと、2 人のときに間が空きすぎる。
         */
        const tight = Math.min(1, Math.max(0.45, around.length / 10));

        around.forEach((node, index) => {
            const angle = (Math.PI * 2 * index) / around.length - Math.PI / 2;
            positions.set(node.id, {
                x: CENTER_X + Math.cos(angle) * RADIUS_X * tight,
                y: CENTER_Y + Math.sin(angle) * RADIUS_Y * tight,
            });
        });
    } else {
    nodes.forEach((node, index) => {
        const saved = dragging?.id === node.id ? dragging.position : layout[node.id];
        if (saved) {
            /*
             * ★ 紙を広げたら、置いた場所も一緒に伸ばす。
             *
             *   覚えているのは、いちばん狭い紙での位置。
             *   そのまま使うと、広げたときに丸が左上へ固まる。
             *
             *   つまんで動かしている最中の位置は、
             *   もう今の紙での値なので、そのまま使う。
             */
            /*
             * ★ 覚えた場所は、紙に対する割合で持つ。
             *
             *   0〜1 の値で覚えておき、いまの紙に掛ける。
             *
             *   そのままの座標で覚えると、紙を広げたときに
             *   丸だけ左上に取り残され、右下が空になる。
             *
             *   割合で持てば、紙を広げても狭めても
             *   同じ場所にいる。見かけ上、丸は動かない。
             *
             * ★ 掴んでいる最中は、そのまま使う。
             *   指の位置は、もういまの紙での値なので。
             */
            const isDragging = dragging?.id === node.id;

            /*
             * ★ 昔の覚え方にも合わせる。
             *
             *   前は座標そのもの（100 や 800）で覚えていた。
             *   それを割合として読むと、みな左上の角に潰れる。
             *
             *   1 より大きければ昔の覚え方とみなし、
             *   そのときの紙（1600×1000）での割合に直す。
             */
            const asRatio =
                saved.x > 1 || saved.y > 1
                    ? { x: saved.x / 1600, y: saved.y / 1000 }
                    : saved;

            positions.set(
                node.id,
                clampToBoard(
                    isDragging
                        ? saved
                        : { x: asRatio.x * WIDTH, y: asRatio.y * HEIGHT },
                ),
            );
            return;
        }
        // 上から時計回りに並べる
        const angle = (Math.PI * 2 * index) / nodes.length - Math.PI / 2;
        positions.set(node.id, {
            /* 板が横長なので、輪も横長にする */
            x: CENTER_X + Math.cos(angle) * RADIUS_X,
            y: CENTER_Y + Math.sin(angle) * RADIUS_Y,
        });
    });
    }

    /*
     * こちらが並べたものだけ、重なりをほどく。
     * 掴んでいるものと、手で置いたものは動かさない。
     */
    const fixedIds = new Set<string>(
        nodes
            .filter((node) => layout[node.id] || dragging?.id === node.id)
            .map((node) => node.id),
    );
    untangle(positions, fixedIds);

    /*
     * 重なりをほどく。
     *
     * ★ 近すぎる丸を、少しずつ押し離す。
     *
     *   円周に等間隔で置いても、項目が増えれば
     *   丸と丸、丸と名前が重なる。
     *   重なると、どれの名前なのか読めない。
     *
     * ★ 手で置いたものは動かさない。
     *   置いた場所には意味がある。
     *   動かすのは、こちらが並べたものだけ。
     *
     * ★ 何度も少しずつ。
     *   一度に離すと、弾かれて端に貼り付く。
     */
    function untangle(
        place: Map<string, { x: number; y: number }>,
        fixed: Set<string>,
    ) {
        const ids = Array.from(place.keys());

        for (let round = 0; round < 60; round += 1) {
            let moved = false;

            for (let a = 0; a < ids.length; a += 1) {
                for (let b = a + 1; b < ids.length; b += 1) {
                    const one = place.get(ids[a]);
                    const two = place.get(ids[b]);
                    if (!one || !two) continue;

                    const dx = two.x - one.x;
                    const dy = two.y - one.y;
                    const gap = Math.hypot(dx, dy);

                    const want = MIN_GAP * spread;
                    if (gap >= want) continue;

                    moved = true;

                    /* 真上に重なっているときは、適当な向きへ逃がす */
                    const angle = gap < 0.01 ? (a + b) * 1.7 : Math.atan2(dy, dx);
                    const push = (want - gap) / 2;

                    const stepX = Math.cos(angle) * push;
                    const stepY = Math.sin(angle) * push;

                    if (!fixed.has(ids[a])) {
                        place.set(ids[a], clampToBoard({
                            x: one.x - stepX,
                            y: one.y - stepY,
                        }));
                    }
                    if (!fixed.has(ids[b])) {
                        place.set(ids[b], clampToBoard({
                            x: two.x + stepX,
                            y: two.y + stepY,
                        }));
                    }
                }
            }

            if (!moved) break;
        }
    }

    /** 図の外へ出さない。掴んだまま端を越えると見失う */
    /*
     * 板の中に留める。
     *
     * ★ 壁は作らない。枠の中は、関係図の紙そのもの。
     *
     *   前は丸を内側で止めていた。
     *   端に置きたいのに置けず、見えない壁に当たる。
     *   紙の端まで使えるほうが、並べ方が自由になる。
     *
     * ★ 外へは出さない。
     *
     *   紙の外に置くと、そこは描かれない。
     *   丸も線も消えたように見える。
     *   端で止めるのは、そのためだけ。
     */
    function clampToBoard(point: { x: number; y: number }) {
        /*
         * 紙の中に留める。
         *
         * ★ 止めるのは、紙の外は描かれないから。それだけ。
         *
         * ★ 向きによって、要る余裕が違う。
         *
         *   左・右・上  丸の縁まで。名前はここに出ない。
         *   下          名前の高さぶん。丸の下に出るので。
         *
         *   前は四方すべてに名前ぶんの余裕を取っていた。
         *   上と左右には要らないので、そのぶん端まで行けない。
         */
        const side = NODE_RADIUS;
        const bottom = NODE_RADIUS + 34;

        return {
            x: Math.min(WIDTH - side, Math.max(side, point.x)),
            y: Math.min(HEIGHT - bottom, Math.max(side, point.y)),
        };
    }

    /** 図の中の座標に直す。画面の大きさが変わっても合うように */
    /*
     * ★ 中心に見ているときは、掴んで動かさない。
     *
     *   並びはこちらで決めているので、動かしても
     *   全体に戻したときには残らない。
     *   動くのに残らないのは、いちばん困る。
     */
    function toGraphPoint(event: { clientX: number; clientY: number }) {
        const svg = svgRef.current;
        if (!svg) return null;

        const rect = svg.getBoundingClientRect();

        /*
         * ★ 板と器の形は、そろえてある。
         *
         *   板の比（ASPECT）を、そのまま器にも掛けてある。
         *   余白が入らないので、枠の幅と高さで割ればよい。
         */
        /*
         * ★ 余白のぶんを足して数える。
         *
         *   描く範囲は紙より一回り大きい。
         *   紙の幅だけで割ると、そのぶん掴む位置がずれる。
         */
        /* 名前が紙の広さのつまみとぶつからないようにする */
        const spanX = WIDTH + PAD * 2;
        const spanY = HEIGHT + PAD * 2;

        return {
            x: ((event.clientX - rect.left) / rect.width) * spanX - PAD,
            y: ((event.clientY - rect.top) / rect.height) * spanY - PAD,
        };
    }

    /*
     * 整理する。
     *
     * ★ 繋がりの多いものを内側へ。
     *
     *   多くの相手と結ばれているものは、
     *   図の真ん中にあるほうが紐が短く済む。
     *   端に置くと、そこから長い紐が何本も伸びる。
     *
     * ★ 輪は、入るぶんだけ。
     *   入りきらないぶんは外の輪へ回す。
     *   詰め込むと、また重なる。
     *
     * ★ 最後にほどく。
     *   輪に並べただけでは、輪と輪の間で重なる。
     */
    function tidy() {
        if (!onMove) return;

        const degree = new Map<string, number>();
        for (const relation of relations) {
            degree.set(relation.from_entry_id, (degree.get(relation.from_entry_id) ?? 0) + 1);
            degree.set(relation.to_entry_id, (degree.get(relation.to_entry_id) ?? 0) + 1);
        }

        const sorted = [...nodes].sort(
            (a, b) => (degree.get(b.id) ?? 0) - (degree.get(a.id) ?? 0),
        );

        const place = new Map<string, { x: number; y: number }>();
        const want = MIN_GAP * spread;

        let at = 0;
        let ring = 0;

        while (at < sorted.length) {
            /*
             * 内側から数えて ring 番目の輪。
             * いちばん内側（0）は、真ん中に 1 つだけ置く。
             */
            if (ring === 0) {
                place.set(sorted[at].id, { x: CENTER_X, y: CENTER_Y });
                at += 1;
                ring += 1;
                continue;
            }

            /*
             * 輪の大きさ。板が横長なので、横と縦で別に持つ。
             * 同じにすると、縦だけ先に端へ着いて詰まる。
             */
            const ry = Math.min(
                CENTER_Y - NODE_RADIUS - 8,
                (want * ring) / 1.6,
            );
            const rx = Math.min(CENTER_X - NODE_RADIUS - 8, ry * ASPECT);

            /* この輪に入る数。詰めすぎない */
            const room = Math.max(1, Math.floor((Math.PI * (rx + ry)) / want));
            const count = Math.min(room, sorted.length - at);

            for (let i = 0; i < count; i += 1) {
                const angle = (Math.PI * 2 * i) / count - Math.PI / 2;
                place.set(sorted[at + i].id, {
                    x: CENTER_X + Math.cos(angle) * rx,
                    y: CENTER_Y + Math.sin(angle) * ry,
                });
            }

            at += count;
            ring += 1;

            /* 輪を増やしても入らないときは、そこで止める */
            if (ry >= CENTER_Y - NODE_RADIUS - 8 && count === 0) break;
        }

        untangle(place, new Set());

        for (const node of nodes) {
            const point = place.get(node.id);
            if (point) onMove(node.id, point);
        }
    }

    const active = hoveredId ?? selectedId;
    /*
     * この作品で使われている、関係の大枠。
     *
     * 47 種類の名前を、6 つにまとめたもの。
     * 凡例には、これだけを出す。
     */
    const usedGroups = RELATION_GROUPS.filter((group) =>
        relations.some((relation) => groupOf(relation.label).key === group.key),
    );

    const body = (
        <div className="flex h-full flex-col">
            {/*
              * いまの姿を、一行で。
              *
              * ★ 全体像を確かめる場所なので、
              *   数がそろっているかを、まず出す。
              *
              *   結んだ人・まだの人・関係の本数。
              *   これだけで「あと誰が残っているか」が分かる。
              */}
            {/*
              * 名前で探す。
              *
              * ★ 人が増えると、目で探すのは無理。
              *   打った字を含む人だけを、はっきり出す。
              *   ほかは薄くして、場所だけ分かるようにする。
              *
              * ★ 人が少ないうちは出さない。
              *   4 人の図に探す欄があっても、邪魔なだけ。
              */}
            {entries.length >= 8 && (
                <input
                    type="text"
                    value={findText}
                    onChange={(e) => setFindText(e.target.value)}
                    placeholder="名前で探す"
                    aria-label="名前で探す"
                    className="mb-1.5 w-40 rounded-md border border-line bg-surface px-2.5 py-1 text-[12px] outline-none focus:border-forest"
                />
            )}

            <p className="mb-1.5 text-[11px] text-muted">
                {nodes.length}人を{relations.length}本の関係で結んでいます。
            </p>

            {/*
              * 章で絞る。
              *
              * ★ 誰かが章を入れているときだけ出す。
              *
              *   何も入力していない作品に出しても、
              *   どれを押しても同じ図になる。
              *   使えないものは置かない。
              */}
            {allChapters.length > 0 && (
                <div className="mb-2 flex flex-wrap items-center gap-1.5">
                    <span className="text-[10.5px] text-faint">章で見る</span>

                    <button
                        type="button"
                        onClick={() => setChapter(null)}
                        aria-pressed={chapter === null}
                        className={[
                            "rounded-md border px-2.5 py-0.5 text-[11px]",
                            chapter === null
                                ? "border-forest bg-forest-tint/60 text-forest"
                                : "border-line text-muted hover:border-forest-line",
                        ].join(" ")}
                    >
                        全部
                    </button>

                    {allChapters.map((one) => (
                        <button
                            key={one}
                            type="button"
                            onClick={() => setChapter(one)}
                            aria-pressed={chapter === one}
                            className={[
                                "rounded-md border px-2.5 py-0.5 text-[11px]",
                                chapter === one
                                    ? "border-forest bg-forest-tint/60 text-forest"
                                    : "border-line text-muted hover:border-forest-line",
                            ].join(" ")}
                        >
                            {one}章
                        </button>
                    ))}
                </div>
            )}

            {/*
              * 図の置き場。
              *
              * ★ 送らない。枠に収める。
              *
              *   前は広げたぶんだけ図を大きくして、
              *   はみ出したところを送って見てもらっていた。
              *   だが送らないと全体が見えないなら、
              *   広く使える意味がない。関係図は
              *   「全部を一目で見る」ための絵なので。
              *
              *   図そのものは枠いっぱいに縮めて描く。
              *   「広さ」は、丸と丸の間の空き方になる。
              *   広げるほど丸は小さくなるが、全部見える。
              *
              * ★ 押し具と凡例は、下に貼り付けたまま。
              */}
            {/*
              * ★ 上下左右に送れるようにする。
              *
              *   一枚を大きくすると、枠からはみ出す。
              *   はみ出したところは、送って見る。
              *
              * ★ 真ん中から見えるようにする。
              *   左上から始まると、いちばん見たい真ん中が
              *   毎回外れている。
              */}
            <div
                ref={panRef}
                className="thin-scroll min-h-0 flex-1 overflow-auto"
            >
                {/*
                  * ★ 縦にも真ん中へ置くための、内側の一枚。
                  *
                  *   margin: auto は横しか真ん中にしない。
                  *   縦が上に張り付いて、下が大きく空いていた。
                  *
                  *   枠と同じ大きさを下限に持つ入れ物を挟み、
                  *   その中で縦横とも真ん中に寄せる。
                  *   紙が枠より大きいときは、この入れ物ごと伸びる。
                  */}
                {/*
                  * ★ はみ出しているときは、真ん中に寄せない。
                  *
                  *   寄せたまま大きくすると、
                  *   左と上へはみ出したぶんが掴めなくなる。
                  *   送っても端まで戻れない。
                  *
                  *   枠より小さいときだけ寄せる。
                  */}
                <div
                    className={[
                        "flex min-h-full min-w-full",
                        scale > 1
                            ? "items-start justify-start"
                            : "items-center justify-center",
                    ].join(" ")}
                >
            <svg
                ref={svgRef}
                /*
                 * ★ 紙の外側に、少し余白を持たせる。
                 *
                 *   端に置いた丸は、そのままだと半分切れ、
                 *   下に出る名前も消える。
                 *
                 *   描く範囲だけ外へ広げる。
                 *   置ける場所は紙の中のまま。
                 */
                viewBox={`${-PAD} ${-PAD} ${WIDTH + PAD * 2} ${HEIGHT + PAD * 2}`}
                className={[
                    "mx-auto block",
                    dragging ? "cursor-grabbing" : "",
                ].join(" ")}
                /*
                 * ★ 高さで決めて、幅は正方形に合わせる。
                 *
                 *   幅と高さを別々に % で指定すると、
                 *   枠の形によって図が歪む。丸が楕円になる。
                 *   高さだけ決めて、幅は 1 対 1 で追わせる。
                 *
                 * ★ 50% が枠ぴったり。だから 2 倍して渡す。
                 */
                /*
                 * ★ 幅で決めて、高さは板の比に合わせる。
                 *   枠は横に長いので、幅のほうが先に足りなくなる。
                 * ★ 50% が枠ぴったり。だから 2 倍して渡す。
                 */
                /*
                 * ★ 一枚の大きさ。
                 *
                 *   いちばん小さいときは、枠の中にすっかり収まる。
                 *   上下にも送りが出ないよう、高さで合わせる。
                 *
                 *   幅で合わせると、板が横長なので
                 *   高さが余り、縦の送りだけが残っていた。
                 *
                 * ★ いちばん大きいときは、その 2 倍。
                 *   前は 2.8 倍で、大きすぎた。
                 */
                /*
                 * ★ 実寸で決める。
                 *
                 *   割合（%）で指定すると、入れ物の作りによって
                 *   伸びたり伸びなかったりする。
                 *   真ん中から先で大きくならなかったのは、これ。
                 *
                 *   枠の高さを測って、その何倍かで出す。
                 *
                 * ★ 0 で枠の 3 割、100 で 1.2 倍。
                 *   前はいちばん大きいが 2 倍で、大きすぎた。
                 */
                /*
                 * ★ 枠いっぱいに使う。
                 *
                 *   前は高さだけを見て決めていた。
                 *   枠が横に長いと、横が余ったままになる。
                 *
                 *   横と縦の両方を見て、
                 *   「ちょうど収まる大きさ」を先に出す。
                 *   つまみは、そこからの倍率。
                 *
                 * ★ つまみがいちばん左のとき、1.0 倍。
                 *   紙の全体が、枠にぴったり収まる。
                 */
                /*
                 * ★ 縦も横も、実寸で決める。
                 *
                 *   比（aspectRatio）に任せると、
                 *   入れ物の作りによって片方が伸びない。
                 *
                 * ★ 縮めさせない（flexShrink: 0）。
                 *
                 *   送る枠は横並びの入れ物で、
                 *   はみ出した絵は勝手に縮められる。
                 *   つまみを動かしても大きくならなかったのは、これ。
                 */
                style={{
                    /*
                     * ★ 文字と同じ並び方をやめる。
                     *
                     *   そのままだと、絵が文字の足元の線に乗り、
                     *   下に数ピクセルの隙間ができる。
                     *   そのぶんはみ出して送りが出て、
                     *   幅が減って、さらにはみ出す。
                     */
                    display: "block",
                    width: fitHeight
                        ? `${Math.floor(fitHeight * scale * liveAspect)}px`
                        : "100%",
                    height: fitHeight
                        ? `${Math.floor(fitHeight * scale)}px`
                        : "100%",
                    flexShrink: 0,
                    flexGrow: 0,
                }}
                role="img"
                aria-label="関係図"
                onPointerMove={(event) => {
                    /* 線の中間点をつまんでいるとき */
                    if (bending) {
                        /*
                         * ★ 中間点も、板の中に留める。
                         *
                         *   外へ置けるようにしたが、
                         *   板の外は描かれないので線が切れて見えた。
                         *   置いたはずの点も消える。
                         *
                         *   板を広く取ってあるので、
                         *   中だけでも十分に回せる。
                         */
                        const point = toGraphPoint(event);
                        if (!point) return;
                        setBending({ ...bending, position: clampToBoard(point) });
                        return;
                    }

                    if (!dragging) return;
                    const point = toGraphPoint(event);
                    if (!point) return;
                    setDragging({
                        ...dragging,
                        moved: true,
                        position: clampToBoard({
                            x: point.x - dragging.offset.x,
                            y: point.y - dragging.offset.y,
                        }),
                    });
                }}
                /*
                 * ★ 何も無いところを押したら、全体に戻す。
                 *
                 *   中心に見ているとき、外れた場所を押すと
                 *   そのままだった。戻る道が押し具だけなのは、
                 *   下まで目を動かすことになる。
                 *
                 *   図そのものを押せば戻る。
                 */
                onPointerDown={(event) => {
                    if (event.target === event.currentTarget) {
                        onSelect(null);
                    }
                }}
                onPointerUp={() => {
                    /* 線の中間点を離したとき */
                    if (bending) {
                        onBend?.(bending.id, bending.position);
                        setBending(null);
                        return;
                    }

                    if (!dragging) return;

                    /*
                     * ★ 中心に見ているあいだに動かしたぶんは、覚えない。
                     *
                     *   あの並びはこちらが置き直したもの。
                     *   そこでの位置を覚えると、
                     *   全体に戻したときに並びが崩れる。
                     */
                    if (focusId) {
                        if (!dragging.moved) {
                            onSelect(selectedId === dragging.id ? null : dragging.id);
                        }
                        setDragging(null);
                        return;
                    }
                    // 動かさずに離したときは、選んだものとして扱う
                    /*
                     * ★ 覚えるときは、いちばん狭い紙での値に戻す。
                     *   広げた状態の値をそのまま覚えると、
                     *   狭めたときに紙からはみ出す。
                     */
                    /*
                     * ★ 覚えるときは、紙に対する割合に直す。
                     *   0〜1 で持てば、紙の広さが変わっても合う。
                     */
                    if (dragging.moved) {
                        onMove?.(dragging.id, {
                            x: dragging.position.x / WIDTH,
                            y: dragging.position.y / HEIGHT,
                        });
                    }
                    else onSelect(selectedId === dragging.id ? null : dragging.id);
                    setDragging(null);
                }}
                onPointerLeave={() => {
                    if (bending) {
                        onBend?.(bending.id, bending.position);
                        setBending(null);
                    }
                    if (dragging?.moved && !focusId) {
                        onMove?.(dragging.id, {
                            x: dragging.position.x / WIDTH,
                            y: dragging.position.y / HEIGHT,
                        });
                    }
                    setDragging(null);
                }}
            >
                {/*
                  * 紙の縁。
                  *
                  * ★ どこまでが紙かを、目に見えるようにする。
                  *
                  *   丸を置ける範囲は、この中だけ。
                  *   縁が見えないと、どこで止まっているのか、
                  *   止まっているのが正しいのかが分からない。
                  *
                  *   いちばん小さくしたとき、この縁が
                  *   枠にぴったり重なるのが正しい姿。
                  */}
                <rect
                    x="0.5"
                    y="0.5"
                    width={WIDTH - 1}
                    height={HEIGHT - 1}
                    fill="none"
                    stroke="var(--color-brand-border)"
                    strokeWidth="1"
                    strokeDasharray="6 6"
                    opacity="0.5"
                />

                {/*
                 * 丸に落とす影。
                 * 板の上に置かれているように見せる。
                 */}
                <defs>
                    {/*
                      * 矢印の先。
                      *
                      * ★ 線の色ごとに用意する。
                      *   SVG の矢印は、線の色を引き継がない。
                      *   家族の線に敵対の色の矢印が付くと、読み違える。
                      */}
                    {RELATION_GROUPS.map((group) => (
                        <marker
                            key={group.key}
                            id={`arrow-${group.key}`}
                            viewBox="0 0 10 10"
                            refX="9"
                            refY="5"
                            markerWidth="6"
                            markerHeight="6"
                            orient="auto-start-reverse"
                        >
                            <path d="M0 0 L10 5 L0 10 z" fill={group.color} />
                        </marker>
                    ))}

                    <filter id="node-shadow" x="-40%" y="-40%" width="180%" height="180%">
                        <feDropShadow
                            dx="0"
                            dy="2"
                            stdDeviation="3"
                            floodColor="#1f4e6b"
                            floodOpacity="0.14"
                        />
                    </filter>
                </defs>

                {shownRelations.map((relation) => {
                    const from = positions.get(relation.from_entry_id);
                    const to = positions.get(relation.to_entry_id);
                    if (!from || !to) return null;

                    /* この線が、いま選んでいる人につながっているか */
                    const touchesActive =
                        !!active &&
                        (relation.from_entry_id === active ||
                            relation.to_entry_id === active);

                    const isActive = !active || touchesActive;

                    /*
                     * 線の曲げ方。
                     *
                     * ★ 中間点が決めてあれば、そこを通す。
                     *
                     *   決めていなければ、中心へ少し引き寄せる。
                     *   直線だけだと、線が重なって読めない。
                     *
                     * ★ つまんでいる最中は、指の位置を使う。
                     */
                    /*
                     * 中間点。
                     *
                     * ★ 中心に見ているときは、使わない。
                     *
                     *   あの並びは、こちらが置き直したもの。
                     *   丸だけ動かして中間点をそのままにすると、
                     *   線が遠くへ引っ張られて、尖った形になる。
                     *
                     *   置き直した並びには、置き直した線を引く。
                     */
                    const bent = focusId
                        ? null
                        : bending?.id === relation.id
                          ? bending.position
                          : (relation.bend ?? null);

                    /*
                     * 線の引き方。
                     *
                     * ★ 中間点を決めてあれば、そこを通る二本の直線。
                     *
                     *   曲線の「制御点」は線の上に乗らない。
                     *   つまんだ点と線が離れていて、
                     *   どこを動かしているのか分からなかった。
                     *
                     *   二本の直線にすれば、点は必ず線の上にある。
                     *   直角に曲げることもできる。
                     *
                     * ★ 決めていなければ、これまでどおり緩く曲げる。
                     */
                    /*
                     * ★ ふだんはまっすぐ引く。
                     *
                     *   前は中心へ引き寄せて緩く曲げていた。
                     *   線が重なるのを避けるためだったが、
                     *   紙を広げたので、重なることは減った。
                     *
                     *   曲げたいときは、中間点を置いてもらう。
                     *   勝手に曲げるより、そのほうが分かりやすい。
                     */
                    const path = bent
                        ? `M${from.x} ${from.y} L${bent.x} ${bent.y} L${to.x} ${to.y}`
                        : `M${from.x} ${from.y} L${to.x} ${to.y}`;

                    /*
                     * 関係の名前を置くところ。
                     *
                     * ★ 線の上に置く。
                     *
                     *   曲線のときは、真ん中の点を出す。
                     *   制御点に置くと、線から浮いて見える。
                     */
                    const labelAt = bent
                        ? bent
                        : { x: (from.x + to.x) / 2, y: (from.y + to.y) / 2 };

                    const controlX = labelAt.x;
                    const controlY = labelAt.y;

                    /*
                     * 線の形。
                     *
                     * 決めていなければ、これまでどおり
                     * 変化の記録があれば実線、無ければ破線。
                     */
                    const lineStyle =
                        relation.line_style ??
                        (relation.changes.length > 0 ? "solid" : "dashed");

                    return (
                        /*
                          * ★ 選んでいる人から遠い線は、ほとんど消す。
                          *
                          *   前は 0.15 で残していたが、
                          *   47 本もあると、薄くても地が埋まる。
                          *   見るべき線だけを残す。
                          */
                        <g key={relation.id} opacity={isActive ? 1 : 0.06}>
                            {/*
                              * ★ 線を二度押すと、中間点が出る。
                              *
                              *   押しやすいよう、見えない太い線を重ねる。
                              *   細い線をぴたりと押すのは、指では無理。
                              */}
                            <path
                                d={path}
                                fill="none"
                                stroke="transparent"
                                strokeWidth="14"
                                style={{ cursor: "pointer" }}
                                onDoubleClick={(event) => {
                                    event.stopPropagation();
                                    setOpenBendId(
                                        openBendId === relation.id
                                            ? null
                                            : relation.id,
                                    );
                                }}
                            />

                            <path
                                d={path}
                                fill="none"
                                stroke={colorOf(relation.label)}
                                strokeWidth={relation.changes.length > 0 ? 2.4 : 1.6}
                                /*
                                 * 線の形。
                                 *
                                 * ★ 決めてあれば、それを使う。
                                 * ★ 決めていなければ、これまでどおり
                                 *   変化の記録があれば実線、無ければ破線。
                                 */
                                strokeDasharray={
                                    lineStyle === "dashed" ? "7 6" : "0"
                                }
                                markerEnd={
                                    lineStyle === "arrow"
                                        ? `url(#arrow-${groupOf(relation.label).key})`
                                        : undefined
                                }
                            />
                            {/*
                              * 中間点。つまんで、線の通り道を決める。
                              *
                              * ★ 選んでいる線にだけ出す。
                              *
                              *   47 本すべてに点を置くと、
                              *   図が点だらけになる。
                              *
                              * ★ 二度押しで、元の曲げ方に戻す。
                              *   動かしすぎたときに、戻す道が要る。
                              */}
                            {/*
                              * 中間点。
                              *
                              * ★ ふだんは出さない。
                              *
                              *   47 本すべてに点が出ると、
                              *   関係の名前と見分けが付かず、
                              *   図が点だらけになる。
                              *
                              *   線を二度押したときだけ出す。
                              */}
                            {onBend && !focusId && openBendId === relation.id && (
                                <circle
                                    cx={controlX}
                                    cy={controlY}
                                    r={bending?.id === relation.id ? 7 : 4.5}
                                    fill="var(--color-canvas)"
                                    stroke={colorOf(relation.label)}
                                    strokeWidth="2"
                                    style={{ cursor: "grab" }}
                                    onPointerDown={(event) => {
                                        event.stopPropagation();
                                        (event.target as Element).setPointerCapture?.(
                                            event.pointerId,
                                        );
                                        setBending({
                                            id: relation.id,
                                            position: { x: controlX, y: controlY },
                                        });
                                    }}
                                    onDoubleClick={(event) => {
                                        event.stopPropagation();
                                        onBend(relation.id, null);
                                    }}
                                >
                                    <title>
                                        つまむと線の通り道が変わります（二度押しで元に戻す）
                                    </title>
                                </circle>
                            )}

                            {/*
                             * 関係の名前。
                             *
                             * ★ ふだんは出さない。
                             *
                             *   47 本あれば、47 個の札が中央に散らばる。
                             *   図の真ん中が文字で埋まり、
                             *   どの線を見ればよいのか分からなくなる。
                             *
                             *   誰かを選んだとき、その人につながる線にだけ出す。
                             *   知りたいのは「いま見ている人との間柄」なので、
                             *   それで足りる。
                             *
                             * ★ 白い札で囲む。
                             *   線の上に直に置くと、線が字を横切って読めない。
                             */}
                            {relation.label && touchesActive && (
                                <>
                                    <rect
                                        x={controlX - relation.label.length * 4.5 - 5}
                                        y={controlY - 9}
                                        width={relation.label.length * 9 + 10}
                                        height={18}
                                        rx={5}
                                        fill="var(--color-surface)"
                                        stroke="var(--color-line)"
                                        strokeWidth="1"
                                    />
                                    <text
                                        x={controlX}
                                        y={controlY + 3.5}
                                        textAnchor="middle"
                                        fontSize="20"
                                        fill={colorOf(relation.label)}
                                    >
                                        {relation.label}
                                    </text>
                                </>
                            )}
                        </g>
                    );
                })}

                {shownNodes.map((node) => {
                    const position = positions.get(node.id);
                    if (!position) return null;
                    const isActive = !active || node.id === active;

                    return (
                        <g
                            key={node.id}
                            opacity={
                                /*
                                 * ★ 名前で探しているときは、そちらを優先する。
                                 *   合う人だけをはっきり出し、
                                 *   ほかは薄くして場所だけ残す。
                                 */
                                findText.trim()
                                    ? node.name.includes(findText.trim())
                                        ? 1
                                        : 0.12
                                    : isActive
                                      ? 1
                                      : 0.3
                            }
                            onMouseEnter={() => setHoveredId(node.id)}
                            onMouseLeave={() => setHoveredId(null)}
                            onPointerDown={(event) => {
                                if (!onMove) {
                                    onSelect(node.id === selectedId ? null : node.id);
                                    return;
                                }
                                event.preventDefault();
                                const point = toGraphPoint(event);
                                if (!point) return;
                                setDragging({
                                    id: node.id,
                                    position,
                                    offset: {
                                        x: point.x - position.x,
                                        y: point.y - position.y,
                                    },
                                    moved: false,
                                });
                            }}
                            className={onMove ? "cursor-grab" : "cursor-pointer"}
                        >
                            {pictures[node.id] ? (
                                <>
                                    <clipPath id={`clip-${node.id}`}>
                                        <circle
                                            cx={position.x}
                                            cy={position.y}
                                            r={NODE_RADIUS}
                                        />
                                    </clipPath>
                                    <image
                                        href={pictures[node.id]}
                                        x={position.x - NODE_RADIUS}
                                        y={position.y - NODE_RADIUS}
                                        width={NODE_RADIUS * 2}
                                        height={NODE_RADIUS * 2}
                                        clipPath={`url(#clip-${node.id})`}
                                    />
                                </>
                            ) : (
                                <circle
                                    cx={position.x}
                                    cy={position.y}
                                    r={NODE_RADIUS}
                                    fill="var(--color-forest-tint)"
                                    filter="url(#node-shadow)"
                                />
                            )}

                            <circle
                                cx={position.x}
                                cy={position.y}
                                r={NODE_RADIUS}
                                fill="none"
                                stroke={
                                    node.id === selectedId
                                        ? "var(--color-forest)"
                                        : "transparent"
                                }
                                strokeWidth={node.id === selectedId ? 2.5 : 0}
                            />

                            {!pictures[node.id] && (
                                <text
                                    x={position.x}
                                    y={position.y + 5}
                                    textAnchor="middle"
                                    fontSize="30"
                                    fontWeight="600"
                                    fill="var(--color-forest)"
                                >
                                    {Array.from(node.name)[0] ?? "?"}
                                </text>
                            )}

                            <text
                                x={position.x}
                                y={position.y + NODE_RADIUS + 28}
                                textAnchor="middle"
                                /*
                                 * ★ 枠に収めるほど、文字は縮む。
                                 *
                                 *   図は枠いっぱいに縮めて描くので、
                                 *   紐を長くするほど文字も小さくなる。
                                 *   名前が読めなければ、図の意味がない。
                                 *
                                 *   丸に対して字を大きくする。
                                 *   重なりは、丸どうしの間（MIN_GAP）で防ぐ。
                                 */
                                fontSize="24"
                                fontWeight="500"
                                fill="var(--color-ink)"
                            >
                                {node.name.length > 8
                                    ? `${node.name.slice(0, 8)}…`
                                    : node.name}
                            </text>
                        </g>
                    );
                })}

            </svg>
                </div>
            </div>

            {onMove && (
                <>
                    <div className="mt-2 flex flex-wrap items-center justify-center gap-3">
                        {/*
                          * ★ つまみは 1 つ。
                          *
                          *   紙を広げると、枠に収めるぶん小さく見える。
                          *   狭めると、枠に収まらず送って見る。
                          *   拡大と同じことをしているので、分けない。
                          */}
                        <label className="flex items-center gap-2">
                            <span className="text-[11px] text-faint">大きさ</span>
                            <span className="text-[9px] text-faint">大</span>

                            <input
                                type="range"
                                min={0}
                                max={100}
                                step={5}
                                value={wideValue}
                                onChange={(e) => setWideValue(Number(e.target.value))}
                                aria-label="図の大きさ"
                                className="w-36 accent-[var(--color-forest)]"
                            />

                            <span className="text-[12px] text-faint">小</span>
                        </label>

                        <button
                            type="button"
                            onClick={tidy}
                            className="rounded-md border border-forest bg-surface px-3 py-1 text-[11px] text-forest hover:bg-forest-tint/60"
                        >
                            整理する
                        </button>

                        {/*
                          * 画面いっぱい。
                          *
                          * ★ 印にする。
                          *   言葉で書くと場所を取るうえ、
                          *   拡大の印は、どこで見ても同じ形をしている。
                          */}
                        <button
                            type="button"
                            onClick={() => setIsFull((open) => !open)}
                            aria-label={
                                isFull ? "元の大きさに戻す" : "画面いっぱいに広げる"
                            }
                            title={
                                isFull ? "元の大きさに戻す" : "画面いっぱいに広げる"
                            }
                            className="rounded-md border border-line p-1.5 text-muted hover:border-forest-line hover:text-forest"
                        >
                            <ExpandIcon isFull={isFull} />
                        </button>
                    </div>

                    <div className="mt-1.5 flex items-center justify-between gap-2">
                        <p className="text-[11px] text-faint">
                            丸をつまむと動かせます。線を二度押すと、通り道を変える点が出ます。
                        </p>
                        {Object.keys(layout).length > 0 && (
                            <button
                                type="button"
                                onClick={() => onReset?.()}
                                className="shrink-0 text-[11px] text-forest hover:underline"
                            >
                                {nodes.length}人を並べ直す
                            </button>
                        )}
                    </div>
                </>
            )}

            {/*
              * 凡例。
              *
              * ★ 6 つだけ出す。
              *
              *   前は関係の名前をぜんぶ並べていた。
              *   作品によっては 47 個あり、5 段になって
              *   図より下の帯のほうが賑やかだった。
              *
              *   色で分けるのは「どういう間柄か」の大枠だけ。
              *   細かい名前は、その人を選んだときに線の上へ出る。
              *
              * ★ 使われている大枠だけ出す。
              *   その作品に無い色を並べても意味がない。
              */}
            <ul className="mt-3 flex flex-wrap justify-center gap-x-5 gap-y-1.5">
                {usedGroups.map((group) => (
                    <li
                        key={group.key}
                        className="flex items-center gap-2 text-xs text-muted"
                    >
                        <svg width="26" height="6" aria-hidden="true">
                            <line
                                x1="0"
                                y1="3"
                                x2="26"
                                y2="3"
                                stroke={group.color}
                                strokeWidth="2.6"
                                strokeLinecap="round"
                            />
                        </svg>
                        {group.label}
                    </li>
                ))}
            </ul>

            <p className="mt-3 text-center text-xs text-faint">
                {chapter !== null
                    ? `${chapter}章に出る人だけを出しています。章を決めていない人は、どの章でも出ます。`
                    : focusId
                    ? "この人と直につながる人だけを出しています。実線は変化を記録した関係です。"
                    : active
                      ? "実線は変化を記録した関係、破線はまだ記録がない関係です。"
                      : "丸を押すと、その人を中心にした図になります。"}
            </p>
        </div>
    );

    if (!isFull) return body;

    /*
     * 画面いっぱい。
     *
     * ★ 中身は同じものをそのまま入れる。
     *   別に作ると、広げたときだけ動きが違う、が起きる。
     *
     * ★ 覆いを押しても閉じない。
     *   丸を掴んで端まで運んだとき、指が覆いに乗る。
     *   そこで閉じると、置いた場所が消える。
     */
    return (
        <div
            style={{
                position: "fixed",
                inset: 0,
                zIndex: 800,
                background: "var(--color-canvas)",
                padding: 16,
                display: "flex",
                flexDirection: "column",
            }}
            role="dialog"
            aria-modal="true"
            aria-label="関係図（画面いっぱい）"
        >
            {body}
        </div>
    );
}

/**
 * 拡大の印。
 *
 * ★ 言葉で書かない。
 *   どこで見ても同じ形なので、印のほうが早い。
 *   読む画面の拡大にも、同じ形を使う。
 */
function ExpandIcon({ isFull }: { isFull: boolean }) {
    return (
        <svg width="15" height="15" viewBox="0 0 16 16" aria-hidden="true">
            {isFull ? (
                <path
                    d="M6.5 1.5v5h-5M9.5 14.5v-5h5"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                />
            ) : (
                <path
                    d="M1.5 5.5v-4h4M14.5 10.5v4h-4M1.5 10.5v4h4M14.5 5.5v-4h-4"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                />
            )}
        </svg>
    );
}
