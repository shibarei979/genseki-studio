/**
 * ============================================================
 * 原石航路 Studio
 * TypoReportsTab — 届いた誤字報告
 *
 * ★ 読めるのは 3 者だけ。
 *   作品の作者・報告した本人・運営。
 *   表の決まりでそう定めてあるので、
 *   ここでは自分の作品ぶんだけが返ってくる。
 *
 * ★ 消す操作には確認を出す。
 *   戻せないため。
 * ============================================================
 */

"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";

import { createClient } from "@/lib/supabase/client";

interface Row {
    id: string;
    novel_id: string;
    episode_id: string | null;
    original_text: string;
    suggested_text: string | null;
    note: string | null;
    created_at: string;
    novel_title?: string | null;
    episode_title?: string | null;
}


/**
 * 誤字の印。
 *
 * ★ 赤い字だけだと、何の行なのか分かりにくい。
 *   字の横に小さな筆の絵を置いて、指摘だと一目で分かるようにする。
 */
function PenMark() {
    return (
        <svg
            width="15"
            height="15"
            viewBox="0 0 24 24"
            fill="none"
            stroke="var(--color-danger)"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
            style={{ flexShrink: 0, marginTop: 5 }}
        >
            <path d="M12 20h9" />
            <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" />
        </svg>
    );
}

export default function TypoReportsTab() {
    const [rows, setRows] = useState<Row[] | null>(null);
    const [error, setError] = useState("");

    const load = useCallback(async () => {
        try {
            const supabase = createClient();

            const {
                data: { user },
            } = await supabase.auth.getUser();

            if (!user) {
                setRows([]);
                return;
            }

            /*
             * ★ 自分の作品ぶんだけを読む。
             *
             *   表の決まりでは、運営はすべての報告を読める。
             *   そのため運営が開くと、他人の作品の報告まで並んでいた。
             *   ここは「作者が自分あての指摘を見る場所」なので、
             *   自分の作品の id で必ず絞る。
             */
            const { data: mine } = await supabase
                .from("novels")
                .select("id")
                .eq("author_id", user.id);

            const myNovelIds = (mine ?? []).map((one: { id: string }) => one.id);

            if (myNovelIds.length === 0) {
                setRows([]);
                return;
            }

            const { data, error: readError } = await supabase
                .from("typo_reports")
                .select("id, novel_id, episode_id, original_text, suggested_text, note, created_at")
                .in("novel_id", myNovelIds)
                .order("created_at", { ascending: false })
                .limit(200);

            if (readError) throw readError;

            const list = (data ?? []) as Row[];

            /*
             * 作品名と話名を足す。無くても一覧は出す。
             *
             * ★ Set を展開しない。
             *   この作りの型の設定（target）では展開が使えず、
             *   送るときに止まる。同じ id を落とすだけなので filter でよい。
             */
            const novelIds = list
                .map((one) => one.novel_id)
                .filter((id, at, all) => all.indexOf(id) === at);

            const episodeIds = list
                .map((one) => one.episode_id)
                .filter((id): id is string => !!id)
                .filter((id, at, all) => all.indexOf(id) === at);

            const [novels, episodes] = await Promise.all([
                novelIds.length
                    ? supabase.from("novels").select("id, title").in("id", novelIds)
                    : Promise.resolve({ data: [] }),
                episodeIds.length
                    ? supabase.from("episodes").select("id, title").in("id", episodeIds)
                    : Promise.resolve({ data: [] }),
            ]);

            /*
             * ★ Map も使わない。
             *   古い型の設定では扱いが渋いので、ただの入れ物にする。
             */
            const novelName: Record<string, string> = {};
            for (const one of (novels.data ?? []) as { id: string; title: string }[]) {
                novelName[one.id] = one.title;
            }

            const episodeName: Record<string, string> = {};
            for (const one of (episodes.data ?? []) as { id: string; title: string }[]) {
                episodeName[one.id] = one.title;
            }

            setRows(
                list.map((one) => ({
                    ...one,
                    novel_title: novelName[one.novel_id] ?? null,
                    episode_title: one.episode_id
                        ? (episodeName[one.episode_id] ?? null)
                        : null,
                })),
            );
        } catch (caught) {
            setError(
                caught instanceof Error
                    ? `読み込めませんでした（${caught.message}）`
                    : "読み込めませんでした",
            );
            setRows([]);
        }
    }, []);

    useEffect(() => {
        void load();
    }, [load]);

    async function handleDelete(id: string) {
        if (!window.confirm("この報告を消します。元には戻せません。")) return;

        try {
            await createClient().from("typo_reports").delete().eq("id", id);
            setRows((prev) => (prev ?? []).filter((one) => one.id !== id));
        } catch {
            window.alert("消せませんでした。時間をおいて試してください。");
        }
    }

    if (rows === null) {
        return <p style={{ fontSize: 13, color: "var(--color-text-faint)" }}>読み込んでいます</p>;
    }

    return (
        <div>
            <div style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 15, fontWeight: 700, color: "var(--color-text)" }}>
                    誤字報告
                </div>
                <div style={{ marginTop: 4, fontSize: 12, color: "var(--color-text-muted)", lineHeight: 1.9 }}>
                    読んだ人が見つけた誤字が届きます。ここに出るのは、あなたの作品ぶんだけです。
                    <br />
                    ほかの読者には見えません。直すかどうかは、あなたが決めてください。
                </div>
            </div>

            {error && (
                <p style={{ fontSize: 12, color: "var(--color-danger)" }}>{error}</p>
            )}

            {rows.length === 0 && !error && (
                <p style={{ fontSize: 13, color: "var(--color-text-faint)", lineHeight: 1.9 }}>
                    いまは届いていません。
                    <br />
                    読んだ人が誤字を見つけたときだけ、ここに並びます。
                </p>
            )}

            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {rows.map((row) => (
                    <div
                        key={row.id}
                        style={{
                            border: "1px solid var(--color-brand-border)",
                            borderRadius: 10,
                            padding: "12px 14px",
                            background: "var(--color-bg-card)",
                        }}
                    >
                        <div style={{ fontSize: 11.5, color: "var(--color-text-muted)" }}>
                            {row.novel_title || "作品"}
                            {row.episode_title ? ` ／ ${row.episode_title}` : ""}
                        </div>

                        <div style={{ marginTop: 8, display: "flex", alignItems: "flex-start", gap: 8, fontSize: 13, color: "var(--color-text)", lineHeight: 1.8 }}>
                            {/* 指摘だと一目で分かるように、字の横に印を置く */}
                            <PenMark />
                            <span style={{ color: "var(--color-danger)" }}>{row.original_text}</span>
                            {row.suggested_text && (
                                <>
                                    <span style={{ margin: "0 6px", color: "var(--color-text-faint)" }}>→</span>
                                    <span style={{ color: "var(--color-brand)" }}>{row.suggested_text}</span>
                                </>
                            )}
                        </div>

                        {row.note && (
                            <div
                                style={{
                                    marginTop: 8,
                                    padding: "8px 10px",
                                    borderRadius: 8,
                                    background: "var(--color-bg)",
                                    fontSize: 12.5,
                                    color: "var(--color-text-muted)",
                                    whiteSpace: "pre-wrap",
                                }}
                            >
                                {row.note}
                            </div>
                        )}

                        <div style={{ marginTop: 10, display: "flex", gap: 12, alignItems: "center" }}>
                            {row.episode_id && (
                                <Link
                                    href={`/workspace/${row.novel_id}?ep=${row.episode_id}`}
                                    style={{ fontSize: 12, color: "var(--color-brand)", textDecoration: "none" }}
                                >
                                    その話を直す →
                                </Link>
                            )}

                            <button
                                type="button"
                                onClick={() => void handleDelete(row.id)}
                                style={{
                                    marginLeft: "auto",
                                    background: "none",
                                    border: "none",
                                    cursor: "pointer",
                                    fontSize: 11.5,
                                    color: "var(--color-danger)",
                                    padding: 0,
                                }}
                            >
                                消す
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
