import { createClient } from '@/lib/supabase/server'
import { ageFromBirthdate, allowedRatings } from '@/lib/age'
import { ROOT_ADMIN_EMAIL } from '@/types'
import Link from 'next/link'

import { getCachedRecommendScores, buildRecommendation } from '@/lib/recommend'
import WorkPopupFlag from '@/components/home/work-popup-flag'
import ReaderSidebar from '@/components/home/reader-sidebar'
import ReaderWorkList from '@/components/home/reader-work-list'
import FeaturedShowcase from '@/components/home/featured-showcase'
import ReadingRecap from '@/components/home/reading-recap'
import ShelfPauseOnHover from '@/components/home/shelf-pause-on-hover'
import HomeBannerCarousel from '@/components/home/home-banner-carousel'
import ReaderHero from '@/components/home/reader-hero'
import ShelfNav from '@/components/home/shelf-nav'
import BirthdateNotice from '@/components/birthdate-notice'
import BookshelfSection from '@/components/home/bookshelf-section'
import HomeEffects from '@/components/home/home-effects'
import Footer from '@/components/layout/footer'
import Header from '@/components/layout/header'
import type { HomeBook, HomeNotice } from '@/types/home'
import { loadBlockedIds } from '@/lib/social/blocks'

/*
 * revalidate はページ側で持つ。
 * 部品に書いても効かないので、page.tsx へ移した。
 */

// ============================================================
// 定数
// ============================================================
/* 本棚の冊数。home.js の B_SIDE_COUNT=10 に合わせる */
/* 本棚の冊数。home.js の B_SIDE_COUNT=10 に合わせる */
const SHELF_COUNT = 25
const WORKS_POOL_COUNT = 20   // Pick Up! / New Release! の候補プール数（初期表示は10冊）
const READING_LIST_COUNT = 8  // 4カラムリストの各件数
const NOTICE_COUNT = 8        // お知らせの最大表示件数（畳み込み時は4件）
/*
 * 本を開いたときの左ページに出す字数。
 *
 * 1 話の冒頭ではなく、あらすじを出す。
 * 冒頭は「読めば分かる」もので、
 * どんな話かを知りたい人には遠回り。
 *
 * ページが広いので、書けるだけ書く。
 */
const HEAD_LENGTH = 400
const EXCERPT_LENGTH = 80     // 抜粋の文字数
const NOTICE_FALLBACK_IMAGE = '/home/img/notice/tmp.png'

// ============================================================
// ユーティリティ
// ============================================================
function truncate(text: string | null | undefined, length: number): string {
  if (!text) return ''
  const t = text.replace(/\r?\n/g, ' ').trim()
  return t.length > length ? t.slice(0, length) + '…' : t
}

function shuffle<T>(list: T[]): T[] {
  const a = [...list]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

/** 件数固定のセクションを「準備中」で末尾まで埋める（レイアウトは変えない） */
function padWithPlaceholders(books: HomeBook[], count: number, kind: string): HomeBook[] {
  const padded = books.slice(0, count)
  while (padded.length < count) {
    padded.push({
      id: `${kind}-placeholder-${padded.length}`,
      href: '#',
      title: '作品タイトル（準備中）',
      author: '作者（準備中）',
      tags: ['ジャンル'],
      head: '',
      excerpt: '',
      comment: '',
      likes: 0,
      placeholder: true,
    })
  }
  return padded
}

function formatMonthDay(dateText: string): string {
  const d = new Date(dateText)
  return `${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`
}

interface NovelRow {
  id: string
  title: string
  summary: string | null
  catchcopy: string | null
  genre: string
  tags: string[] | null
  author_id: string
  created_at: string
  /* 並べ替えと絞り込みに使う */
  updated_at?: string | null
  novel_type?: string | null
  serial_status?: string | null
}

/** novels 行 + 付随情報 → 本の統一フォーマット（デザインの book_template.js と同一キー） */
function toBook(
  novel: NovelRow,
  extras: {
    authorMap: Record<string, string>
    likeMap: Record<string, number>
    headMap: Record<string, string>
    commentMap: Record<string, string>
  },
  href?: string,
): HomeBook {
  return {
    id: novel.id,
    href: href ?? `/novel/${novel.id}`,
    title: novel.title,
    author: extras.authorMap[novel.author_id] || '不明な作者',
    /*
     * 本に挿す付箋。
     *
     * ジャンルだけ。1 枚に絞る。
     * タグまで並べると、背表紙の上が付箋で埋まり、
     * どれが何の印か分からなくなる。
     */
    tags: [novel.genre].filter(Boolean),
    /* 左ページ。あらすじを出す。無ければ 1 話の冒頭で代える */
    head: truncate(novel.summary, HEAD_LENGTH) || extras.headMap[novel.id] || '',
    /*
     * 帯に出す文。
     *
     * 拡散のひとことだけを出す。
     * あらすじやキャッチコピーは、作者が書いたもの。
     * 帯は「読んだ人の声」を載せる場所なので、
     * 拡散されていない本の帯は空にする。
     */
    excerpt: '',
    comment: extras.commentMap[novel.id] || '',
    likes: extras.likeMap[novel.id] || 0,
  }
}

// ============================================================
// ページ本体
// ============================================================
/**
 * 読者ホームを、開いたときに一度だけ読み込み直す。
 *
 * ★ 本棚が最初の組み立てで崩れることがある。
 *
 *   幅の取れ方が端末やタイミングで変わり、
 *   本の大きさと位置が食い違ったまま固まる。
 *   読み込み直すと直るので、それを自動でやる。
 *
 * ★ 一度だけ。
 *   記録を残さないと、永遠に読み込み直し続ける。
 *   sessionStorage に印を置き、
 *   その窓を閉じるまでは二度としない。
 */
function ReloadOnce() {
    return (
        <script
            dangerouslySetInnerHTML={{
                __html: `
(function () {
  try {
    var key = 'genseki:home-reloaded';
    if (sessionStorage.getItem(key)) return;
    sessionStorage.setItem(key, '1');
    window.location.reload();
  } catch (e) {
    /* 記録できない環境では、読み込み直さない。
       印が残せないと、繰り返しになるため */
  }
})();
                `.trim(),
            }}
        />
    );
}

export default async function ReaderHome() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  /*
   * その人が見てよい区分。
   *
   * 生年月日が未設定なら all だけ。
   * 自分の作品と、運営は例外にする。
   */
  const { data: viewer } = user
    ? await supabase
        .from('profiles')
        .select('birthdate, role, show_ai_works')
        .eq('user_id', user.id)
        .maybeSingle()
    : { data: null }

  const ratings = allowedRatings(
    ageFromBirthdate((viewer as { birthdate?: string } | null)?.birthdate),
  )

  const isAdmin =
    user?.email === ROOT_ADMIN_EMAIL ||
    (viewer as { role?: string } | null)?.role === 'admin'

  /*
   * 作品プールとおすすめスコア。
   *
   * ★ 「作られた新しい順」で切らない。
   *
   *   前は新しく作られた 60 件だけを母集団にしていた。
   *   だが「最新話更新」は、更新の新しい順に並べる場所。
   *
   *   去年作られた作品でも、今日続きが出たなら
   *   いちばん上に来るべき。それが 60 件の外にいると、
   *   何をしても出てこない。
   *
   *   「8月に作った作品の続きを出したのに、
   *   最新話更新に出ない」はこれが原因。
   *
   * ★ 200 件に広げる。
   *   作品が増えたら、また見直すこと。
   */
  const poolQuery = supabase
    .from('novels')
    .select('id, title, summary, catchcopy, genre, tags, author_id, created_at, age_rating, novel_type, serial_status, updated_at')
    .eq('published', true)
    .order('created_at', { ascending: false })
    .limit(200)

  const [{ data: newestRaw }, scoredAll] = await Promise.all([
    isAdmin
      ? poolQuery
      : /*
         * 自分の作品は年齢に関わらず出す。
         * 書いた本人から自作が消えると、
         * 消されたのかと思って問い合わせが来る。
         */
        poolQuery.or(
          `age_rating.in.(${ratings.join(',')})${user ? `,author_id.eq.${user.id}` : ''}`,
        ),
    getCachedRecommendScores(),
  ])
  /*
   * ブロックした作者の作品を、本棚から落とす。
   *
   * 読み終えてから落とす。問い合わせの側で外そうとすると、
   * 相手が多いときに URL が長くなりすぎて通らない。
   */
  const blockedAuthors = await loadBlockedIds(supabase, user?.id)
  /*
   * AI が本文を書いた作品を外す。
   *
   * ★ マイページで「出さない」を選んだ人にだけ。
   *   何も決めていない人には、これまでどおり見せる。
   *
   * ★ ai_usage が 'full' のものだけ外す。
   *   'assist'（下調べなどに使った）は残す。
   *   表紙を AI で作っただけの作品も残る。
   */
  const hideAi = (viewer as { show_ai_works?: boolean } | null)?.show_ai_works === false

  const newest: NovelRow[] = (newestRaw || []).filter(
    (n: NovelRow) =>
      !blockedAuthors.has((n as { author_id?: string }).author_id ?? '')
      && !(hideAi && (n as { ai_usage?: string }).ai_usage === 'full'),
  )
  const novelById: Record<string, NovelRow> = {}
  newest.forEach((n) => { novelById[n.id] = n })

  /*
   * 読めない作品を、棚から外す。
   *
   * ★ 話が 1 つも無い作品が並んでいた。
   *   題名も空のまま、作者名だけの本になっていた。
   *
   *   しかも押すと「このページはありません」になる。
   *   作品ページは、話が 0 件なら読者に見せない作りだから。
   *
   * 題名の無いものも外す。棚に置いても何の本か分からない。
   */
  const readableIds = new Set<string>()

  /*
   * 最後に話が出た時刻。
   *
   * ★ 「最新話更新」は、これで並べる。
   *
   *   前は novels.updated_at で並べていた。
   *   だがあれは、話を出したとき以外でも動く。
   *   同じ時刻が何十作品も並ぶことがあり、
   *   「投稿したのに一番上に行かない」が起きていた。
   *
   *   話が出た時刻そのもので並べれば、間違いようがない。
   */
  const lastPostedMap: Record<string, string> = {}

  {
    const ids = newest.map((n) => n.id)
    if (ids.length > 0) {
      /*
       * ★ limit は効かない。range で分けて取る。
       *
       *   既定で 1000 行までしか返らない。
       *   200 作品ぶんの話は、それを軽く超える。
       *   途中で切れると、下のほうの作品が
       *   「話が無い」扱いになって消える。
       */
      for (let from = 0; from < 100000; from += 1000) {
        const { data: page } = await supabase
          .from('episodes')
          .select('novel_id, posted_at, created_at')
          .in('novel_id', ids)
          .eq('is_published', true)
          .range(from, from + 999)

        if (!page || page.length === 0) break

        for (const row of page as {
          novel_id: string
          posted_at: string | null
          created_at: string | null
        }[]) {
          readableIds.add(row.novel_id)

          /* 出た時刻。無ければ作った時刻で代える */
          const at = row.posted_at || row.created_at
          if (!at) continue

          const now = lastPostedMap[row.novel_id]
          if (!now || at > now) lastPostedMap[row.novel_id] = at
        }

        if (page.length < 1000) break
      }
    }
  }

  /*
   * 運営が選んだ作品。
   *
   * 受賞が 1 つでもあれば、受賞だけを出す。
   * 受賞とただの推薦が混ざると、
   * どれが賞を取ったのか分からなくなる。
   */
  const { data: featuredRows } = await supabase
    .from('featured_novels')
    .select('novel_id, kind, label, sort_order, contest_id, prize, starts_page')
    .eq('is_visible', true)
    .order('sort_order', { ascending: true })
    .limit(50)

  const featured = (featuredRows || []) as {
    novel_id: string; kind: string; label: string; sort_order: number
    contest_id?: string | null; prize?: string | null; starts_page?: boolean
  }[]

  /*
   * コンテストの名前と帯の絵。
   * 本の横に出すのに使う。賞の名前だけでは、どの催しか伝わらない。
   */
  const contestIds = [...new Set(featured.map((f) => f.contest_id).filter(Boolean))] as string[]
  const contestById = new Map<string, { title: string; banner_url: string | null }>()

  if (contestIds.length > 0) {
    const { data: contestRows } = await supabase
      .from('contests')
      .select('id, title, banner_url')
      .in('id', contestIds)

    for (const row of contestRows || []) {
      contestById.set(row.id as string, {
        title: (row.title as string) || '',
        banner_url: (row.banner_url as string) || null,
      })
    }
  }
  /*
   * 見せ場の動き。運営が管理画面で決める。
   *
   * 表がまだ無い、行がまだ無い、のどちらでも動くようにする。
   * 読めなければ、これまでと同じ 3 冊・送りなしで出す。
   */
  const { data: fsSettingRow } = await supabase
    .from('featured_settings')
    .select('auto_seconds')
    .maybeSingle()

  const featuredAutoSeconds = Number(fsSettingRow?.auto_seconds ?? 0)

  const awards = featured.filter((f) => f.kind === 'award')
  const picked = awards.length > 0 ? awards : featured.filter((f) => f.kind === 'pick')

  const featuredTitle = awards.length > 0 ? '受賞作品' : '運営のおすすめ'
  const featuredLabels: Record<string, string> = {}
  /* 運営が置いた切れ目。この作品から新しい板が始まる */
  const featuredBreaks: Record<string, boolean> = {}
  const featuredContest: Record<string, { id: string; title: string; banner: string | null }> = {}

  for (const f of picked) {
    /*
     * 札に出す文。
     *
     * 賞の種類（大賞など）があれば、それを出す。
     * 無ければ、これまでどおり自由に書いた文。
     */
    const prize = (f.prize || '').trim()
    if (f.starts_page) featuredBreaks[f.novel_id] = true

    if (prize) featuredLabels[f.novel_id] = prize
    else if (f.label.trim()) featuredLabels[f.novel_id] = f.label.trim()

    if (f.contest_id) {
      const contest = contestById.get(f.contest_id)
      if (contest) {
        featuredContest[f.novel_id] = {
          id: f.contest_id,
          title: contest.title,
          banner: contest.banner_url,
        }
      }
    }
  }

  /*
   * 選ばれた作品は、別に読む。
   *
   * ★ ホームの読み込みは「新しい順に60件」。
   *   運営が選んだ作品が古いと、その60件から外れて出なかった。
   *
   *   選んだのに出ないのでは、選ぶ意味がない。
   *   id を名指しで読み直す。
   *
   * 読める作品かどうかは、ここでも確かめる。
   * 話が1つも無い作品を見せ場に置くと、開いても何も無い。
   */
  const featuredNovelById = new Map<string, NovelRow>()
  if (picked.length > 0) {
    const ids = picked.map((f) => f.novel_id)

    const [{ data: pickedNovels }, { data: pickedEpisodes }] = await Promise.all([
      supabase
        .from('novels')
        .select('id, title, summary, catchcopy, genre, tags, author_id, created_at, age_rating, novel_type, serial_status, updated_at')
        .in('id', ids)
        .eq('published', true),
      supabase
        .from('episodes')
        .select('novel_id')
        .in('novel_id', ids)
        .eq('is_published', true)
        .limit(1000),
    ])

    const live = new Set(
      (pickedEpisodes || []).map((e: { novel_id: string }) => e.novel_id),
    )

    for (const novel of (pickedNovels || []) as NovelRow[]) {
      if (!live.has(novel.id)) continue
      if ((novel.title ?? '').trim() === '') continue
      featuredNovelById.set(novel.id, novel)

      /*
       * 作者名を引く一覧にも入れる。
       * ここへ入れておかないと、60件の外の作品は
       * 作者名が空のまま出る。
       */
      novelById[novel.id] = novel
    }
  }

  const readable = newest.filter(
    (n) => readableIds.has(n.id) && (n.title ?? '').trim() !== '',
  )


  // ----- ユーザーがよく読むジャンル（旧トップページと同じロジック） -----
  let favoriteGenres: string[] = []
  if (user) {
    const { data: myReads } = await supabase
      .from('read_episodes').select('novel_id').eq('user_id', user.id).limit(100)
    const readNovelIds = Array.from(new Set((myReads || []).map((r: any) => r.novel_id)))
    if (readNovelIds.length > 0) {
      const { data: readNovels } = await supabase.from('novels').select('genre').in('id', readNovelIds)
      const genreCount: Record<string, number> = {}
      readNovels?.forEach((n: any) => { genreCount[n.genre] = (genreCount[n.genre] || 0) + 1 })
      favoriteGenres = Object.entries(genreCount).sort((a, b) => b[1] - a[1]).slice(0, 2).map(([g]) => g)
    }
  }

  // ----- Pick Up!（おすすめアルゴリズム）/ New Release! -----
  /*
   * おすすめも同じ物差しで絞る。
   *
   * 集計そのものは全員で共有しているので、
   * 使う直前にここで落とす。
   */
  const scoredForViewer = isAdmin
    ? scoredAll
    : scoredAll.filter((n) =>
        ratings.includes((n.age_rating as 'all' | 'r15' | 'r18') ?? 'all'),
      )

  const pickedScored = buildRecommendation(scoredForViewer, WORKS_POOL_COUNT, favoriteGenres, user?.id)
  const pickupNovels: NovelRow[] = pickedScored.length > 0
    ? pickedScored.map((s) => ({
        id: s.id, title: s.title, summary: s.summary, catchcopy: s.catchcopy,
        genre: s.genre, tags: s.tags, author_id: s.author_id, created_at: s.created_at,
      }))
    : shuffle(readable).slice(0, WORKS_POOL_COUNT)
  pickupNovels.forEach((n) => { if (!novelById[n.id]) novelById[n.id] = n })

  const newReleaseNovels = readable.slice(0, WORKS_POOL_COUNT)
  /*
   * 本棚に並べる作品。
   *
   * 帯（拡散のひとことか、読者が描いたドット絵）が
   * ある作品を先に並べる。
   *
   * 本棚は「読んだ人の声が付いた本」を見せる場所にする。
   * 声の無い本ばかりでは、ただの新着一覧と変わらない。
   *
   * 帯のある作品だけでは冊数が足りないので、
   * 残りは新着から埋める。その本の帯は空になる。
   */
  const { data: obiRows } = await supabase
    .from('obi_dots')
    .select('novel_id')
    .eq('approved', true)

  const { data: obiCommentRows } = await supabase
    .from('discovers')
    .select('novel_id, comment')
    .not('comment', 'is', null)

  const withObi = new Set<string>()
  ;(obiRows || []).forEach((r: any) => withObi.add(r.novel_id as string))
  ;(obiCommentRows || []).forEach((r: any) => {
    if (String(r.comment ?? '').trim()) withObi.add(r.novel_id as string)
  })

  const shelfWithObi = shuffle(readable.filter((n) => withObi.has(n.id)))
  const shelfWithout = shuffle(readable.filter((n) => !withObi.has(n.id)))

  const shelfNovels = [...shelfWithObi, ...shelfWithout].slice(0, SHELF_COUNT)

  // ----- ログインユーザー向け 4カラムリストの素材 -----
  const continueRows: { novel: NovelRow; epId: string }[] = []
  let recommendedNovels: NovelRow[] = []
  const followedUpdateRows: { novel: NovelRow; epId: string }[] = []
  let followedNewNovels: NovelRow[] = []

  if (user) {
    // 続きから読む（閲覧履歴 /history と同じ page_views ベース）
    const { data: views } = await supabase
      .from('page_views')
      .select('episode_id, viewed_at')
      .eq('user_id', user.id)
      .order('viewed_at', { ascending: false })
      .limit(100)
    const epIds = Array.from(new Set((views || []).map((v: any) => v.episode_id).filter(Boolean))).slice(0, 40)
    if (epIds.length > 0) {
      const { data: viewedEps } = await supabase
        .from('episodes')
        .select('id, novel_id, novels(id, title, summary, catchcopy, genre, tags, author_id, created_at, published)')
        .in('id', epIds as string[])
      const orderedEps = (epIds as string[])
        .map((id) => (viewedEps || []).find((e: any) => e.id === id))
        .filter(Boolean) as any[]
      const seen = new Set<string>()
      for (const ep of orderedEps) {
        const novel = ep.novels as NovelRow & { published?: boolean } | null
        if (!novel?.id || !novel.published || seen.has(novel.id)) continue
        seen.add(novel.id)
        continueRows.push({ novel, epId: ep.id })
        novelById[novel.id] = novel
        if (continueRows.length >= READING_LIST_COUNT) break
      }
    }

    // あなたへのおすすめ
    recommendedNovels = buildRecommendation(scoredForViewer, READING_LIST_COUNT, favoriteGenres, user.id)
      .map((s) => ({
        id: s.id, title: s.title, summary: s.summary, catchcopy: s.catchcopy,
        genre: s.genre, tags: s.tags, author_id: s.author_id, created_at: s.created_at,
      }))
    recommendedNovels.forEach((n) => { if (!novelById[n.id]) novelById[n.id] = n })

    // フォローした作者の作品（更新 = 既存作品の新しい話 / 新着 = 新しい作品）
    const { data: follows } = await supabase
      .from('follows').select('following_id').eq('follower_id', user.id)
    const followingIds = (follows || []).map((f: any) => f.following_id)
    if (followingIds.length > 0) {
      const { data: followedNovelsRaw } = await supabase
        .from('novels')
        .select('id, title, summary, catchcopy, genre, tags, author_id, created_at')
        .eq('published', true)
        .in('author_id', followingIds)
        .order('created_at', { ascending: false })
        .limit(30)
      const followedNovels: NovelRow[] = followedNovelsRaw || []
      followedNovels.forEach((n) => { novelById[n.id] = n })
      followedNewNovels = followedNovels.slice(0, READING_LIST_COUNT)

      if (followedNovels.length > 0) {
        const { data: recentEps } = await supabase
          .from('episodes')
          .select('id, novel_id, ep_number, created_at')
          .in('novel_id', followedNovels.map((n) => n.id))
          .gt('ep_number', 1)
          .order('created_at', { ascending: false })
          .limit(40)
        const seen = new Set<string>()
        for (const ep of recentEps || []) {
          if (seen.has(ep.novel_id)) continue
          seen.add(ep.novel_id)
          const novel = novelById[ep.novel_id]
          if (novel) followedUpdateRows.push({ novel, epId: ep.id })
          if (followedUpdateRows.length >= READING_LIST_COUNT) break
        }
      }
    }
  }

  // ----- 付随情報（作者名 / いいね数 / 本文冒頭 / 発掘コメント）を一括取得 -----
  const allIds = Object.keys(novelById)
  const allAuthorIds = Array.from(new Set(Object.values(novelById).map((n) => n.author_id)))

  const [{ data: authors }, { data: likeRows }, { data: firstEps }, { data: discoverRows }] = await Promise.all([
    supabase.from('public_profiles').select('user_id, display_name').in('user_id', allAuthorIds),
    supabase.from('likes').select('novel_id').in('novel_id', allIds),
    supabase.from('episodes').select('novel_id, body').eq('ep_number', 1).in('novel_id', allIds),
    supabase.from('discovers').select('novel_id, comment')
      .in('novel_id', allIds).not('comment', 'is', null).eq('is_pending', false)
      .order('created_at', { ascending: false }).limit(200),
  ])

  const authorMap: Record<string, string> = {}
  authors?.forEach((a: any) => { authorMap[a.user_id] = a.display_name })
  const likeMap: Record<string, number> = {}
  likeRows?.forEach((l: any) => { likeMap[l.novel_id] = (likeMap[l.novel_id] || 0) + 1 })
  const headMap: Record<string, string> = {}
  firstEps?.forEach((e: any) => { if (!headMap[e.novel_id]) headMap[e.novel_id] = truncate(e.body, HEAD_LENGTH) })
  const commentMap: Record<string, string> = {}
  discoverRows?.forEach((d: any) => { if (!commentMap[d.novel_id]) commentMap[d.novel_id] = truncate(d.comment, EXCERPT_LENGTH) })

  const extras = { authorMap, likeMap, headMap, commentMap }

  // ----- 本の統一フォーマットへ変換 -----
  // 各セクションの冊数はデザインで固定（本棚20 / works各10 / 4カラム各8）。
  // 実データが足りない分は「準備中」で末尾を埋め、レイアウトは変えない。
  const shelfBooks = padWithPlaceholders(shelfNovels.map((n) => toBook(n, extras)), SHELF_COUNT, 'shelf')
  const pickupPool = pickupNovels.map((n) => toBook(n, extras))       // 「更新」用プール（実データのみ）
  const newReleasePool = newReleaseNovels.map((n) => toBook(n, extras))

  /*
   * 一覧に出す本。
   *
   * 10 件ずつ。2 列なので 5 行に収まる。
   * 空の枠では埋めない。作品が無ければ、その枠ごと出さない。
   */
  const LIST_SIZE = 10

  const followedBooks = [
    ...followedUpdateRows.map((r) => toBook(r.novel, extras, `/novel/${r.novel.id}/episode/${r.epId}`)),
    ...followedNewNovels.map((n) => toBook(n, extras)),
  ].slice(0, LIST_SIZE)

  /*
   * おすすめ。
   *
   * ログインしていない人には作れない。
   * その場合はこの枠を出さない。
   *
   * 新着で代えると「新しく届いた作品」と
   * 中身が同じ枠が 2 つ並ぶことになる。
   */
  const recommendBooks = recommendedNovels
    .map((n) => toBook(n, extras))
    .slice(0, LIST_SIZE)

  const popularBooks = pickupPool.slice(0, LIST_SIZE)

  /* 続きから読む。読みかけの作品を並べる */
  const continueBooks = continueRows
    .map((r) => toBook(r.novel, extras, `/novel/${r.novel.id}/episode/${r.epId}`))
    .slice(0, LIST_SIZE)

  /* 新しく届いた作品 */
  const newBooks = newReleasePool.slice(0, LIST_SIZE)

  /*
   * 最新話更新。
   *
   * 新しく作品が出たのではなく、
   * 続きが出たものを並べる。
   * 追っている人にとっては、こちらのほうが用がある。
   */
  /*
   * ★ 話が出た時刻で並べる。
   *
   *   作品の updated_at は、話を出したとき以外でも動く。
   *   それで並べると、投稿しても上に来ないことがあった。
   *
   * ★ 1 話だけの作品も出す。
   *
   *   前は「続きが出たもの」に絞っていたが、
   *   初めの 1 話を出した人にとっても、
   *   そこに並ぶことに意味がある。
   *
   *   出したばかりの人が並ばないと、
   *   誰にも気づかれないまま埋もれる。
   */
  const updatedBooks = [...readable]
    .filter((n) => Boolean(lastPostedMap[n.id]))
    .sort((a, b) =>
      String(lastPostedMap[b.id] || '').localeCompare(
        String(lastPostedMap[a.id] || ''),
      ),
    )
    .slice(0, LIST_SIZE)
    .map((n) => toBook(n, extras))

  /*
   * 新作（おすすめ）。
   *
   * 出たばかりで、点数の高いもの。
   * ただ新しいだけでは、読む手がかりにならない。
   */
  const monthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
  /*
   * 新着作品。
   *
   * 点数では選ばず、新しいものから選ぶ。
   * 「新作のおすすめ」は点数で選んでいたので、
   * 新しくても点の低い作品は出てこなかった。
   *
   * ★ 先頭の 10 件をそのまま出さない。
   *
   *   新しい順に並んだ先頭を取ると、
   *   誰かが投稿するまで中身も順番も変わらない。
   *   毎日見に来る人には、同じ棚が並び続ける。
   *
   *   新しいほうから 30 件を母集団にして、その中から選ぶ。
   *   開くたびに顔ぶれが変わる。
   */
  const freshBooks = shuffle(readable.slice(0, WORKS_POOL_COUNT))
    .slice(0, LIST_SIZE)
    .map((n) => toBook(n, extras))

  /*
   * 運営が選んだ作品。
   * 読める作品の中から、選ばれた順に並べる。
   */
  const featuredItems = picked
    .map((f) => {
      const novel = featuredNovelById.get(f.novel_id)
      if (!novel) return null
      return {
        id: novel.id,
        href: `/novel/${novel.id}`,
        title: novel.title || '（題名なし）',
        author: extras.authorMap[novel.author_id] || '名前のない書き手',
        label: featuredLabels[novel.id],
        contestId: featuredContest[novel.id]?.id ?? null,
        startsPage: featuredBreaks[novel.id] === true,
        contestTitle: featuredContest[novel.id]?.title,
        contestBanner: featuredContest[novel.id]?.banner ?? null,
      }
    })
    .filter((x): x is NonNullable<typeof x> => x !== null)
    /*
     * ★ 10 件で切らない。
     *   横に送れるようになったので、選んだものは全部出す。
     *   上限は読み込みの 50 件のほう。
     */

  /* 短編。ひと息で読み切れるもの */
  const shortBooks = readable
    .filter((n) => n.novel_type === '短編')
    .slice(0, LIST_SIZE)
    .map((n) => toBook(n, extras))

  /*
   * 完結作品。
   *
   * 終わりまで書かれている。
   * 途中で止まるのが嫌な人に向けて出す。
   */
  const completedBooks = newest
    .filter((n) => n.serial_status === 'completed')
    .slice(0, LIST_SIZE)
    .map((n) => toBook(n, extras))


  // ----- お知らせ / コンテスト -----
  const [{ data: annRows }, { data: contestRows }] = await Promise.all([
    supabase.from('announcements').select('id, title, body, link, image_url, created_at')
      .eq('is_published', true).order('created_at', { ascending: false }).limit(NOTICE_COUNT),
    /*
     * コンテスト。
     *
     * 絵の見せ方（banner_fit / zoom / x / y）まで読む。
     * これが無いと ContestBanner が既定値を使えず、
     * 絵が拡大されて角しか映らない。
     */
    supabase.from('contests').select('id, title, description, image_url, banner_url, banner_fit, banner_zoom, banner_x, banner_y, is_site_contest, apply_url, created_at')
      .eq('is_published', true).order('created_at', { ascending: false }).limit(NOTICE_COUNT),
  ])

  type DatedNotice = HomeNotice & { createdAt: string }
  const strip = ({ createdAt: _createdAt, ...n }: DatedNotice): HomeNotice => n

  const datedNotices: DatedNotice[] = (annRows || []).map((a: any) => ({
    id: `ann-${a.id}`,
    /*
     * ★ /announcements という頁は無い。
     *
     *   押しても「見つかりません」になっていた。
     *   お知らせのまとめは /notices。
     *
     * link が入っていれば、そちらを優先する。
     * 外の頁を指したいお知らせがあるため。
     */
    href: a.link || '/notices',
    image: a.image_url || NOTICE_FALLBACK_IMAGE,
    time: formatMonthDay(a.created_at),
    title: a.title,
    detail: truncate(a.body, EXCERPT_LENGTH),
    createdAt: a.created_at,
  }))
  const datedContests: DatedNotice[] = (contestRows || []).map((c: any) => ({
    id: `con-${c.id}`,
    href: c.is_site_contest ? `/contests/${c.id}` : (c.apply_url || '/contests'),
    image: c.image_url || NOTICE_FALLBACK_IMAGE,
    time: formatMonthDay(c.created_at),
    title: c.title,
    detail: truncate(c.description, EXCERPT_LENGTH),
    createdAt: c.created_at,
  }))
  const noticeItems = datedNotices.map(strip)

  /*
   * 左の柱に渡すもの。
   *
   * 読みかけは、続きから読むの先頭。
   * 一番最近ひらいた作品が来る。
   */
  /*
   * 柱に出す読みかけ。
   *
   * 執筆側の「執筆中の作品」と同じ形にする。
   * 最後に読んだ日、いま何話目か、全体の何割かを出す。
   */
  const first = continueRows[0]
  let sidebarReading: {
    novelId: string
    episodeId: string
    title: string
    lastReadAt: string
    episodeLabel: string
    readCount: number
    totalCount: number
  } | null = null

  if (first && user) {
    /* その作品の話を並べ、いま何話目かを数える */
    const { data: eps } = await supabase
      .from('episodes')
      .select('id, ep_number')
      .eq('novel_id', first.novel.id)
      .eq('is_published', true)
      .order('ep_number', { ascending: true })
      .limit(1000)

    const list = eps || []
    const at = list.findIndex((e: any) => e.id === first.epId)

    /* 最後に読んだ日 */
    const { data: lastViewRows } = await supabase
      .from('page_views')
      .select('viewed_at')
      .eq('user_id', user.id)
      .eq('episode_id', first.epId)
      .order('viewed_at', { ascending: false })
      .limit(1)

    const lastView = (lastViewRows || [])[0] as { viewed_at?: string } | undefined

    sidebarReading = {
      novelId: first.novel.id,
      episodeId: first.epId,
      title: first.novel.title,
      lastReadAt: lastView?.viewed_at || '',
      episodeLabel:
        at >= 0 ? `${at + 1}話目まで` : '続きから',
      readCount: at >= 0 ? at + 1 : 0,
      totalCount: list.length,
    }
  }

  /*
   * 柱に出すお知らせ。
   *
   * お知らせの置き場は 2 つある。
   *   admin_notices  … Studio で作ったもの
   *   announcements  … 前の版から引き継いだもの
   * 片方だけ読むと、書いたのに出てこないことになる。
   */
  const { data: adminNoticeRows } = await supabase
    .from('admin_notices')
    .select('id, title, published_at, is_published')
    .eq('is_published', true)
    .order('published_at', { ascending: false })
    .limit(NOTICE_COUNT)

  const today = new Date().toISOString().slice(0, 10)

  const sidebarNotices = [
    ...(adminNoticeRows || [])
      /* 表に出す日が来たものだけ */
      .filter((a: any) => String(a.published_at).slice(0, 10) <= today)
      .map((a: any) => ({
        id: `adm-${a.id}`,
        href: '/notices',
        date: formatMonthDay(a.published_at),
        title: a.title as string,
        at: String(a.published_at),
      })),
    ...datedNotices.map((n) => ({
      id: n.id,
      href: n.href,
      date: formatMonthDay(n.createdAt),
      title: n.title,
      at: n.createdAt,
    })),
  ]
    .sort((a, b) => b.at.localeCompare(a.at))
    .slice(0, 3)
  const contestItems = datedContests.map(strip)

  /*
   * 柱に出すコンテスト。2 つまで。
   *
   * 絵の列は banner_url。
   * image_url を見ていて、絵が出ていなかった。
   */
  const sidebarContests = (contestRows || []).slice(0, 2).map((c: any) => ({
    ...c,
    /*
     * 絵の見せ方。
     * 値が入っていない古いものでも崩れないよう、既定を当てる。
     */
    banner_fit: c.banner_fit ?? 'cover',
    banner_zoom: c.banner_zoom ?? 100,
    banner_x: c.banner_x ?? 50,
    banner_y: c.banner_y ?? 50,
  })) as any[]
  /*
   * 中央に出すお知らせ。
   *
   * 柱には文字だけが出る。
   * 絵は柱の幅では小さすぎて、何の告知か伝わらない。
   * 絵のあるものだけを、中央へ回す。
   */
  const boardNotices = (annRows || [])
    /*
     * 絵で絞らない。
     *
     * 絞ると、絵を付けていない日は欄ごと消える。
     * 絵が無いものは、題名だけの札で出す。
     */
    .slice(0, 3)
    .map((a: any) => ({
      id: String(a.id),
      title: a.title as string,
      image: a.image_url as string,
      link: (a.link as string | null) || null,
    }))

  const allNotices = [...datedNotices, ...datedContests]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, NOTICE_COUNT)
    .map(strip)

  // ============================================================
  // レンダリング
  // テーマ・ビュー・ログイン状態は <body> の data 属性が持つ
  // （src/app/layout.tsx がサイト全体で一元管理）
  // ============================================================
  return (
    <div className="page-with-footer bg-canvas">
    {/*
      * 開いたときに一度だけ読み込み直す。
      * 本棚が最初の組み立てで崩れることがあるため。
      */}
    <ReloadOnce />

    {/* ヘッダーは端から端まで */}
    <Header />

    {/*
     * 左右の骨組みは執筆向けと同じ。
     *
     * 白い地と縦の線は外側の aside に持たせ、
     * 頁の下（フッターの手前）まで伸ばす。
     * 貼りつくのは中の箱だけ。
     */}
    {/*
     * 左右の骨組みは執筆向けと同じ。
     *
     * 白い地と縦の線は外側の aside に持たせ、
     * 頁の下（フッターの手前）まで伸ばす。
     * 貼りつくのは中の箱だけ。
     */}
    {/*
     * 見出しと本棚は、柱より上に出して全幅にする。
     *
     * 本棚は横に並べて見せるものなので、幅が要る。
     * 柱の右に置くと、300px ぶん狭い所へ押し込まれる。
     *
     * ★ 本棚は home.js が root.clientWidth を読んで
     *   並べる冊数を決める。幅が変われば計算し直される。
     *   window.resize でも追随する。
     *
     * ★ .reader-home で囲うのを忘れないこと。
     *   本棚の見た目はすべて .reader-home 配下の指定で決まっている。
     *   外に出すと、棚も板も消える。
     */}
    {/*
      * ★ 見出しは .reader-home の外に置くこと。
      *
      *   base.css に .reader-home * { margin:0; padding:0 } がある。
      *   中に入れると、見出しの内側の余白まで消えて
      *   文字が画面の端に張り付く。
      *
      *   囲みが要るのは本棚だけ。
      */}
    <div className="px-5 pb-5 pt-4 sm:px-6">
      <BirthdateNotice />
      {/* 下に余白。本棚とくっついていると、棚が見出しの一部に見える */}
      <ReaderHero />
    </div>

    <div
      className="reader-home"
      data-theme="light"
      data-view="reader"
      data-auth={user ? 'login' : 'guest'}
    >
      <div className="rh_main">
        {/*
         * 本棚と、その下の板。
         * 板が無いと本が宙に浮いて見える。
         */}
        <div className="rh_shelf">
          <BookshelfSection books={shelfBooks} />
          <div className="rh_shelf-board" aria-hidden="true" />

          {/* 手で前後に送る */}
          <ShelfNav />
        </div>
      </div>
    </div>

    {/*
     * 左右の余白を必ず同じにする。
     *
     * 前は「左に固定の余白、右は余りもの」だったので、
     * 画面の幅が変わるたびに左右がずれていた。
     *
     * まとまりの幅を決めて、中央に置く。
     * これなら、どの幅でも左右が同じになる。
     *
     *   柱 352px ＋ 本文 1100px ＋ 本文の左余白 20px = 1472px
     *
     * ★ 幅を変えるときは、この 1472px だけを動かす。
     *   中の割り振り（柱 352 / 本文 1100）は触らない。
     */}
    <div className="mx-auto flex w-full max-w-[1472px]">
      {/*
       * 柱。
       *
       * ★ 白い地と縦の線をやめた。
       *
       *   前は aside に bg-surface と border-r があり、
       *   さらに after で頁の下まで白い面を伸ばしていた。
       *   中身が短くても、白い柱だけが下まで続いていた。
       *
       *   札は自分で白を持っているので、地は要らない。
       *   高さも、中身のぶんだけで終わる。
       *
       * ★ 中身は右へ寄せる。
       *   左に余白を多めに取り、札の左端を内側へ入れる。
       *
       * ★ 上の位置は「作品を探す」にそろえる。
       *   右の main が py-4（16px）なので、こちらも同じにする。
       */}
      {/*
       * 枠を広げる。
       *
       * 300px のままだと、中身をいくら右へ寄せても
       * 枠の右端で止まり、「作品を探す」との間が開いたままだった。
       *
       * 枠を 380px にして、右端が本文のすぐ横まで届くようにする。
       * そのうえで、左の余白で寄せ具合を決める。
       */}
      <aside className="hidden w-[352px] shrink-0 xl:block">
        {/*
         * 左に大きく余白を取って、札を右へ寄せる。
         *
         * 左端に貼り付いていると、右の「作品を探す」との間が
         * 開きすぎて、二つが離れて見える。
         *
         * ★ 寄せ具合はこの pl-* と pr-* の数字だけで変わる。
         *   もっと右へ  pl-20 pr-0
         *   もっと左へ  pl-8  pr-3
         */}
        {/*
         * 札の幅は 300px のまま、左の余白で右へ寄せる。
         *
         * ★ 寄せ具合はこの pl-* だけで変わる。
         *   もっと右へ  pl-20（80px）
         *   もっと左へ  pl-8 （32px）
         */}
        {/*
         * 上の位置を「作品を探す」にそろえる。
         *
         *   main の py-4        16px
         *   .rh_search の上余白 40px
         *   ──────────────────────
         *   合わせて            56px
         *
         * 柱は py-4（16px）しかなく、43px 上にずれていた。
         */}
        {/*
         * 上の位置。
         *
         * 本文側は .rh_search の margin-top が 40px。
         * 柱もそこにそろえる。
         *
         * ★ 数字を足し引きしない。
         *   前は main の py-4（16px）も足して 56px にしたが、
         *   柱には py-4 が掛かっていないので、その分だけ下がった。
         */}
        <div className="sticky top-14 pl-[52px] pr-0 pt-10">
          <ReaderSidebar
            reading={sidebarReading}
            notices={sidebarNotices}
            contests={sidebarContests}
          />
        </div>
      </aside>

      {/* 右 */}
      <div className="flex min-w-0 flex-1 flex-col">
        <main className="min-w-0 flex-1 space-y-3.5 px-5 py-4 sm:px-6">
          {/* 本棚から下は、参照元の見た目で囲う */}
          <div
            id="home-page"
            className="reader-home"
            data-theme="light"
            data-view="reader"
            data-auth={user ? 'login' : 'guest'}
          >
            {/* 見開きの器は layout に置いてある（BookInfoHost） */}
            {/* 見せ方の設定を body に伝える。home.js がそれを見る */}
            <WorkPopupFlag />
            {/* 札の設定のとき、本棚の本を押したら札を出す */}
            {/*
              * 本棚の札は置かない。
              * 札そのものをやめ、見開きに一本化した。
              */}
            <div className="rh_main">

            {/*
             * 作品を探す。
             *
             * 本棚のすぐ下に置く。
             * 棚を眺めて目当てが無かった人が、
             * そのまま探しに行ける。
             */}
            <Link href="/search" className="rh_search">
              <span className="rh_search-icon" aria-hidden="true">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
                  <circle cx="11" cy="11" r="7"/>
                  <path d="m20 20-3.5-3.5"/>
                </svg>
              </span>
              <span className="rh_search-text">
                <span className="rh_search-title">作品を探す</span>
                <span className="rh_search-note">ジャンル・タグ・キーワードで作品を検索できます</span>
              </span>
              <span className="rh_search-go">詳細検索 ›</span>
            </Link>

            {/*
             * 作品の一覧。
             *
             * 上から、追っている作者の新着・おすすめ・注目。
             * 自分に近いものから、広いものへ順に降りる。
             *
             * フォローしていない人には、追っている作者の枠を出さない。
             * 空の枠だけ並んでいても、することが無い。
             */}
            {/*
              * 並びの順。
              *
              * 上から「まだ知らない作品」、下へ「自分に近いもの」。
              * 来た人がまず出会うのは、知らない一冊であってほしい。
              *
              *   受賞 → おすすめ → フォロー中 → 続きから読む
              *   → 新着 → 最新話 → バナー → 短編
              *
              * ★ 受賞をいちばん上に置く。
              *   運営が手で選んだ棚なので、
              *   ここだけは見せ方を決めきってある。
              *   受賞が 1 つも無い日は枠ごと出ないので、
              *   そのときはおすすめが先頭に来る。
              */}

            {/*

              * 先月のまとめ。

              *

              * 月が変わって最初に来たときだけ、小窓で出す。

              * 読む向きのホームにだけ置く。

              * 書くだけの人に読書のまとめを出しても、意味がない。

              */}

            <ReadingRecap />

            {/*
              * 本棚に印を置いているあいだ、送りを止める。
              *
              * 題名を読もうとした本が、読み終える前に
              * 流れていってしまうのを防ぐ。
              */}
            <ShelfPauseOnHover />


            {/*
              * 受賞作品の見せ場。
              *
              * ★ rwl の枠に入れない。
              *   見せ場が自分で枠と見出しを持っているので、
              *   入れると枠が二重になる。
              *
              * ★ 選んだ作品が 1 つも無いときは、枠ごと出ない。
              *   空の板だけが残ると、置き忘れに見える。
              */}
            {featuredItems.length > 0 && (
              <FeaturedShowcase
                title={featuredTitle}
                items={featuredItems}
                autoSeconds={featuredAutoSeconds}
              />
            )}

            <ReaderWorkList
              title="おすすめの作品"
              books={recommendBooks}
              moreHref="/search"
            />

            {/* その時の新着。点数では選ばず、新しい順に出す */}
            {/*
              * ★ 追っている作者と、読みかけを上へ出す。
              *
              *   前はいちばん下だった。
              *   探しに来た人には関係がない、という並べ方だったが、
              *   毎日来る人には、まずこの 2 つに用がある。
              *   下まで指を送らないと届かないのは、
              *   使いにくい。
              *
              * ★ 空のときは、そもそも出ない。
              *   誰も追っていない人の画面では、
              *   これまでどおり新着から始まる。
              */}
            <ReaderWorkList
              title="フォロー中の作家の新着"
              books={followedBooks}
              moreHref="/search?sort=new"
            />

            {/* ひと息で読み切れる */}
            <ReaderWorkList
              title="続きから読む"
              books={continueBooks}
              /* 履歴のページはまだ無い。作品を探すへ送る */
              moreHref="/search"
            />

            <ReaderWorkList
              title="新着作品"
              books={freshBooks}
              moreHref="/search?sort=new"
            />

            <ReaderWorkList
              title="最新話更新"
              books={updatedBooks}
              moreHref="/search?sort=updated"
            />


            {/*
              * ここから下は、その人だけのもの。
              * 読みかけや追っている作者は、
              * 探しに来た人には関係がない。
              */}
            <ReaderWorkList
              title="短編"
              books={shortBooks}
              moreHref="/search?type=短編"
            />



            <div className="rh_banner">
              <HomeBannerCarousel contests={sidebarContests} />
            </div>

            {/*
             * 完結した作品。
             *
             * 数が揃うまでは出さない。
             * 2 冊しか並ばない棚は、かえって寂しく見える。
             * 増えたら false を外す。
             */}
            {false && (
              <ReaderWorkList
                title="完結した作品"
                books={completedBooks}
                moreHref="/search?serial=completed"
              />
            )}
            </div>

            <HomeEffects pools={{ pickupPool, newReleasePool }} />
          </div>
        </main>
      </div>
    </div>

    {/*
      * フッターは詰めて置く。
      *
      * 既定では上に 18rem（288px）の余白が入る。
      * 下まで読み切った人にだけ見せるための隙間だが、
      * 読者ホームは並びが長く、下まで来たら次はフッターでよい。
      */}
    <Footer tight />
    </div>
  )
}
