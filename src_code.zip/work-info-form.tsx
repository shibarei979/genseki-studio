/**
 * ============================================================
 * 原石航路 Studio
 * WorkInfoForm — 設定 / 作品情報
 * ============================================================
 */

"use client";

import Link from "next/link";
import IconCropper from "@/components/mypage/icon-cropper";
import { shrinkImage } from "@/lib/storage/image-store";
import { uploadImage } from "@/lib/storage/remote-image";
import { useRouter, useSearchParams } from "next/navigation";

import { useState } from "react";

import { getRepository } from "@/lib/repository";
import {
    AI_USAGE_DESCRIPTION,
    AI_USAGE_LABEL,
    WORK_FORMAT_DESCRIPTION,
    WORK_FORMAT_LABEL,
} from "@/types";
import TagInput from "@/components/works/tag-input";
import { COVERS } from "@/components/home/home-work-table";
import {
    CATCHPHRASE_MAX_LENGTH,
    SUMMARY_MAX_LENGTH,
    TITLE_MAX_LENGTH,
} from "@/config";
import type {
    AiUsage,
    WorkFormat, AgeRating, Work } from "@/types";
import {
    AGE_RATING_DESCRIPTION,
    AGE_RATING_LABEL,
    GENRES_R18_ONLY,
    selectableGenres,
} from "@/types";

interface Props {
    work: Work;
    /*
     * 公開しているか。
     *
     * 公開の設定は別の表にあるので、外から渡してもらう。
     * ここで読み直すと、開くたびに問い合わせが 1 つ増える。
     */
    isPublished?: boolean;
    onSave: (patch: Partial<Work>) => Promise<void>;
}

export default function WorkInfoForm({
    work,
    isPublished = false,
    onSave,
}: Props) {
    const [title, setTitle] = useState(work.title);
    const [catchphrase, setCatchphrase] = useState(work.catchphrase ?? "");
    const [genre, setGenre] = useState(work.genre);
    const [format, setFormat] = useState<WorkFormat | null>(work.format ?? null);

    /* 表紙。あらすじの横に出る */
    const [coverUrl, setCoverUrl] = useState<string | null>(work.cover_url ?? null);

    /*
     * 本棚に並ぶときの、本の色。
     *
     * null は「おまかせ」。題名から決まる。
     * 同じ題名なら、いつも同じ色になる。
     */
    const [coverColor, setCoverColor] = useState<number | null>(
        work.cover_color ?? null,
    );

    /*
     * 表紙に AI を使ったか。
     *
     * 絵を見ただけでは分からないので、申告してもらう。
     * 立てると、作品ページの表紙の右上にハンコが出る。
     */
    const [coverIsAi, setCoverIsAi] = useState(work.cover_is_ai === true);
    /* AI の印を置く角。空なら右上 */
    const [stampCorner, setStampCorner] = useState<"tl" | "tr" | "bl" | "br">(
        work.cover_stamp_corner ?? "tr",
    );
    const [coverBusy, setCoverBusy] = useState(false);
    const [coverError, setCoverError] = useState("");

    /* 切り抜く前の絵。選んだ直後だけ入る */
    const [cropTarget, setCropTarget] = useState<File | null>(null);

    /** 切り抜いた絵を置く */
    async function putCover(blob: Blob) {
        setCoverBusy(true);
        setCoverError("");

        try {
            const file = new File([blob], "cover.jpg", { type: "image/jpeg" });
            const shrunk = await shrinkImage(file, true);
            const url = await uploadImage(shrunk, "cover");
            setCoverUrl(url);

            /*
             * ここではまだ作品に結びついていない。
             *
             * 下の「保存」を押して初めて表紙になる。
             * それを言わないと、変えたつもりで
             * 前の絵のままになる。
             */
            setSavedMessage("下の「保存」を押すと、この表紙になります");
            window.setTimeout(() => setSavedMessage(""), 6000);
        } catch (caught) {
            setCoverError(
                caught instanceof Error ? caught.message : "画像を置けませんでした。",
            );
        }

        setCoverBusy(false);
    }
    const [aiUsage, setAiUsage] = useState<AiUsage>(work.ai_usage ?? "none");
    const [tags, setTags] = useState<string[]>(work.tags);
    const [summary, setSummary] = useState(work.summary ?? "");
    /*
     * 作者メモは画面から外したが、値は残す。
     * すでに書いた人のものが、開いただけで消えるのは困る。
     */
    const [authorNote] = useState(work.author_note ?? "");
    const [ageRating, setAgeRating] = useState<AgeRating>(work.age_rating);

    /*
     * ジャンルを変えられるか。
     *
     * 公開したあとは、週に 1 回まで。
     * ランキングの空いているジャンルへ移し、
     * 上位に出たらまた戻す、という使い方ができてしまう。
     * 読む人にとっては、探した棚に無い作品が増えるだけになる。
     *
     * 公開する前は何度でも変えられる。
     * 決めかねている段階で縛る理由がない。
     */
    const lastGenreChange = work.genre_changed_at
        ? new Date(work.genre_changed_at)
        : null;

    const nextGenreChangeAt =
        lastGenreChange && !Number.isNaN(lastGenreChange.getTime())
            ? new Date(lastGenreChange.getTime() + 7 * 24 * 60 * 60 * 1000)
            : null;

    /*
     * 年齢の区分を下げたせいで、ジャンルを選び直してもらう状態。
     *
     * こちらの都合で外させたので、
     * 週 1 回の縛りには数えない。
     * 数えると、選び直せないまま空になって公開が続く。
     */
    const mustReselectGenre =
        GENRES_R18_ONLY.includes(work.genre) && ageRating !== "r18";

    const genreLocked = Boolean(
        isPublished &&
            !mustReselectGenre &&
            nextGenreChangeAt &&
            nextGenreChangeAt > new Date(),
    );

    const nextGenreChange = nextGenreChangeAt
        ? `${nextGenreChangeAt.getFullYear()}年${nextGenreChangeAt.getMonth() + 1}月${nextGenreChangeAt.getDate()}日`
        : "";

    /*
     * すすめる読む向き。
     *
     * 決めなくてもよい。読む人の設定はそのまま。
     * 「こちらで読んでほしい」という印を出すだけ。
     */
    const [recommendedMode, setRecommendedMode] = useState<
        "vertical" | "horizontal" | null
    >(work.recommended_mode ?? null);
    /* 本棚での形。決めていなければ縦長 */
    const [coverShape, setCoverShape] = useState<"tall" | "wide">(
        work.cover_shape === "wide" ? "wide" : "tall",
    );

    const [isSaving, setIsSaving] = useState(false);
    const [savedMessage, setSavedMessage] = useState("");

    /*
     * 作ったばかりか。
     * 「新しい作品を作る」からここへ来ると ?new=1 が付く。
     */
    const router = useRouter();
    const params = useSearchParams();
    const isNew = params.get("new") === "1";

    const [isDeleting, setIsDeleting] = useState(false);

    async function handleDelete() {
        await getRepository().deleteWork(work.id);
        router.push("/works");
    }

    const titleError = title.trim().length === 0 ? "タイトルを入れてください。" : "";
    const summaryError = summary.trim().length === 0 ? "あらすじを入れてください。" : "";

    /*
     * まだ決まっていないもの。
     *
     * 3 つだけは早めに決めてほしいので、色で目立たせる。
     * ただし書かせはしない。書き始めてからでないと
     * 決まらないこともある。
     */
    const isBlank = {
        title: title.trim().length === 0,
        genre: genre.trim().length === 0,
        summary: summary.trim().length === 0,
    };
    const blankCount = Object.values(isBlank).filter(Boolean).length;

    /** 未記入の欄の枠 */
    const blankClass =
        "border-[var(--color-amber)] bg-[var(--color-amber-tint)]/40";
    const canSave = !titleError && !summaryError && !isSaving;

    async function handleSave() {
        if (!canSave) return;
        setIsSaving(true);
        setCoverError("");

        /*
         * ★ 失敗を黙って捨てない。
         *
         *   前は書き込みが弾かれても何も出ず、
         *   「保存しました」も出ないだけだった。
         *   表紙が変わらないのに理由が分からない、という声が出た。
         */
        try {
        await onSave({
            title: title.trim(),
            catchphrase: catchphrase.trim() || null,
            genre,
            format,
            ai_usage: aiUsage,
            tags,
            summary: summary.trim(),
            author_note: authorNote.trim() || null,
            age_rating: ageRating,
            /*
             * ジャンルが変わったときだけ、日を打ち直す。
             * ほかの項目を直しただけで数え直すと、
             * 題名を直すたびに 1 週間待たされる。
             */
            ...(genre !== work.genre && !mustReselectGenre
                ? { genre_changed_at: new Date().toISOString() }
                : {}),
            recommended_mode: recommendedMode,
            cover_url: coverUrl,
            cover_is_ai: coverIsAi,
            cover_stamp_corner: stampCorner,
            cover_shape: coverShape,
            cover_color: coverColor,
        });
        setSavedMessage("保存しました");
        window.setTimeout(() => setSavedMessage(""), 2500);
        } catch (caught) {
            setCoverError(
                caught instanceof Error
                    ? `保存できませんでした（${caught.message}）`
                    : "保存できませんでした",
            );
        }
        setIsSaving(false);
    }

    return (
        <div className="rounded-lg border border-line bg-surface">
            <div className="border-b border-line px-6 py-5">
                <h2 className="text-base font-medium text-ink">作品情報</h2>
                <p className="mt-1 text-sm text-muted">作品の基本情報を編集します。</p>

                {blankCount > 0 && (
                    <p className="mt-3 flex items-start gap-2 rounded-md bg-[var(--color-amber-tint)] px-3.5 py-2.5 text-[12px] leading-relaxed text-ink">
                        <span className="mt-0.5 shrink-0 text-[var(--color-amber)]">
                            ●
                        </span>
                        <span>
                            <span className="font-medium">
                                タイトル・ジャンル・あらすじ
                            </span>
                            はまだ決まっていません。
                            あとから変えられますが、
                            早めに決めておくと作品を探しやすくなります。
                        </span>
                    </p>
                )}
            </div>

            <div className="grid gap-6 px-6 py-6 lg:grid-cols-2">
                <div className="space-y-5">
                    <Field label="タイトル" htmlFor="info-title" error={titleError}>
                        <input
                            id="info-title"
                            type="text"
                            value={title}
                            maxLength={TITLE_MAX_LENGTH}
                            onChange={(e) => setTitle(e.target.value)}
                            placeholder="作品の名前"
                            className={[
                                "w-full rounded-md border px-3 py-2 text-sm outline-none focus:border-forest",
                                isBlank.title ? blankClass : "border-line",
                            ].join(" ")}
                        />
                        <Counter current={title.length} max={TITLE_MAX_LENGTH} />
                    </Field>

                    <Field label="キャッチコピー（任意）" htmlFor="info-catch">
                        <input
                            id="info-catch"
                            type="text"
                            value={catchphrase}
                            maxLength={CATCHPHRASE_MAX_LENGTH}
                            onChange={(e) => setCatchphrase(e.target.value)}
                            placeholder="見えない粒が織りなす、もうひとつの魔法世界。"
                            className="w-full rounded-md border border-line px-3 py-2 text-sm outline-none focus:border-forest"
                        />
                        <Counter current={catchphrase.length} max={CATCHPHRASE_MAX_LENGTH} />
                    </Field>

                    <Field label="ジャンル" htmlFor="info-genre">
                        <select
                            id="info-genre"
                            value={genre}
                            disabled={genreLocked}
                            onChange={(e) => setGenre(e.target.value)}
                            className={[
                                "w-full rounded-md border bg-surface px-3 py-2 text-sm outline-none focus:border-forest",
                                isBlank.genre ? blankClass : "border-line",
                                genreLocked ? "opacity-50" : "",
                            ].join(" ")}
                        >
                            {/* まだ決めていない状態を選べるようにする */}
                            <option value="">選んでください</option>
                            {/*
                             * 昔のジャンルは出さない。
                             * 既にそれで出している作品はそのままだが、
                             * これから選ぶ人には新しい分け方で選んでもらう。
                             *
                             * BL・GL は R18 のときだけ出す。
                             * いま選んでいるものは、区分を変えても消さない。
                             */}
                            {selectableGenres(ageRating).map((g) => (
                                <option key={g} value={g}>
                                    {g}
                                </option>
                            ))}
                        </select>

                        {genreLocked ? (
                            <p className="mt-1.5 rounded-md border border-line bg-canvas px-2.5 py-2 text-[11px] leading-relaxed text-muted">
                                公開したあとのジャンルは、週に1回まで変えられます。
                                <br />
                                次に変えられるのは <strong>{nextGenreChange}</strong> からです。
                            </p>
                        ) : (
                            isPublished && (
                                <p className="mt-1.5 text-[11px] text-faint">
                                    公開中の作品です。ジャンルを変えると、
                                    次に変えられるのは1週間後になります。
                                </p>
                            )
                        )}

                        {mustReselectGenre ? (
                            <p className="mt-1.5 rounded-md border border-amber bg-amber-tint/30 px-2.5 py-2 text-[11px] leading-relaxed text-ink">
                                <strong>ジャンルを選び直してください。</strong>
                                <br />
                                「{work.genre}」は R18 の作品だけのジャンルです。
                                年齢の区分を下げたので、選べなくなりました。
                                <br />
                                この選び直しは、週1回の数には入りません。
                            </p>
                        ) : (
                            ageRating !== "r18" && (
                                /*
                                 * ★ この文は「BL・GL が選べない」と読まれていた。
                                 *
                                 *   BL・GL は、どの年齢区分でも選べる。
                                 *   R18 の作品だけのものは、別枠の 3 つ。
                                 *   名前を省いたせいで、要望として
                                 *   「R15 でも BL・GL を」と届いた。
                                 */
                                <p className="mt-1.5 text-[11px] text-faint">
                                    BL・GL は、どの年齢の区分でも選べます。
                                    <br />
                                    {GENRES_R18_ONLY.join("・")} は、年齢の区分を R18
                                    にすると選べます。
                                </p>
                            )
                        )}
                    </Field>

                    {/*
                     * 表紙。
                     *
                     * 作品ページで、あらすじの横に出る。
                     * AI で作った絵は置けない。見分けは付かないので、
                     * ここに書いて約束してもらう。
                     */}
                    {cropTarget && (
                        <IconCropper
                            file={cropTarget}
                            shape="rect"
                            title="表紙を切り抜く"
                            /* 本の表紙らしい縦長。文庫に近い比 */
                            aspect={0.7}
                            onCancel={() => setCropTarget(null)}
                            onDone={(blob) => {
                                setCropTarget(null);
                                void putCover(blob);
                            }}
                        />
                    )}

                    <Field label="表紙" htmlFor="info-cover">
                        <div className="flex items-start gap-3">
                            {coverUrl ? (
                                /*
                                 * 表紙の見本。
                                 *
                                 * 印を立てたとき、実際にどう出るかを
                                 * ここで見せる。作品ページを開き直して
                                 * 確かめるのでは、立てるのをためらう。
                                 */
                                <div className="relative w-24 shrink-0">
                                    {/* eslint-disable-next-line @next/next/no-img-element */}
                                    <img
                                        src={coverUrl}
                                        alt="表紙"
                                        className="w-full rounded-md border border-line object-contain"
                                    />
                                    {coverIsAi && (
                                        /* eslint-disable-next-line @next/next/no-img-element */
                                        <img
                                            src="/images/ai-cover-stamp.png"
                                            alt="この表紙はAI画像を使っています"
                                            /* 作品ページと同じ見え方。大きさだけ表紙に合わせる */
                                            className="pointer-events-none absolute h-10 w-10"
                                            style={{
                                                /* 作者が選んだ角に置く */
                                                top: stampCorner.startsWith("t") ? -4 : undefined,
                                                bottom: stampCorner.startsWith("b") ? -4 : undefined,
                                                left: stampCorner.endsWith("l") ? -4 : undefined,
                                                right: stampCorner.endsWith("r") ? -4 : undefined,
                                                transform: "rotate(-8deg)",
                                                /* 作品ページと同じ薄さ */
                                                opacity: 0.55,
                                                filter:
                                                    "drop-shadow(0 0 2px rgba(255,255,255,.9)) drop-shadow(0 1px 2px rgba(0,0,0,.18))",
                                            }}
                                        />
                                    )}
                                </div>
                            ) : (
                                <div className="flex h-32 w-24 shrink-0 items-center justify-center rounded-md border border-dashed border-line text-[10px] text-faint">
                                    まだ無し
                                </div>
                            )}

                            <div className="min-w-0 flex-1">
                                <input
                                    id="info-cover"
                                    type="file"
                                    accept="image/jpeg,image/png"
                                    disabled={coverBusy}
                                    onChange={async (e) => {
                                        const file = e.target.files?.[0];
                                        e.target.value = "";
                                        if (!file) return;

                                        /* jpeg と png だけ。ほかは受け取らない */
                                        if (
                                            file.type !== "image/jpeg" &&
                                            file.type !== "image/png"
                                        ) {
                                            setCoverError(
                                                "JPEG か PNG の画像を選んでください。",
                                            );
                                            return;
                                        }

                                        /*
                                         * そのまま上げず、切り抜きへ。
                                         *
                                         * 縦横の合わない絵をそのまま出すと、
                                         * 余白ができたり端が切れたりする。
                                         * どこを見せるかは、描いた人が決める。
                                         */
                                        setCoverError("");
                                        setCropTarget(file);
                                    }}
                                    className="block w-full text-xs text-muted file:mr-2 file:rounded file:border file:border-line file:bg-surface file:px-2.5 file:py-1 file:text-xs file:text-ink"
                                />

                                <p className="mt-2 text-[11px] leading-relaxed text-muted">
                                    JPEG または PNG。作品ページで、あらすじの横に出ます。
                                </p>

                                {/*
                                 * AI を使ったかの申告。
                                 *
                                 * 絵を見ただけでは見分けが付かない。
                                 * 隠して出されるより、申告して出せるほうが
                                 * 読む人にとって確かな情報になる。
                                 */}
                                <label
                                    className={[
                                        "mt-2 flex cursor-pointer items-start gap-2.5 rounded-md border px-2.5 py-2",
                                        coverIsAi
                                            ? "border-forest bg-forest-tint/40"
                                            : "border-line bg-surface",
                                    ].join(" ")}
                                >
                                    <input
                                        type="checkbox"
                                        checked={coverIsAi}
                                        onChange={(e) =>
                                            setCoverIsAi(e.target.checked)
                                        }
                                        className="mt-0.5 h-4 w-4 shrink-0"
                                    />
                                    <span className="min-w-0">
                                        <span className="block text-[12px] font-medium text-ink">
                                            この表紙は AI を使って作りました
                                        </span>
                                        <span className="mt-0.5 block text-[11px] leading-relaxed text-muted">
                                            立てると、作品ページの表紙に
                                            「AI」の印が出ます。
                                            {!coverUrl &&
                                                "（表紙を入れると、左に見本が出ます）"}
                                        </span>
                                    </span>
                                </label>

                                {/*
                                  * 印を置く角。
                                  *
                                  * ★ 顔など見せたい所に重なる、という声から足した。
                                  *   選ぶと、左の見本がその場で動く。
                                  */}
                                {coverIsAi && (
                                    <div className="mt-2">
                                        <span className="text-[11px] text-muted">
                                            印を置く角
                                        </span>
                                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                                            {([
                                                ["tl", "左上"],
                                                ["tr", "右上"],
                                                ["bl", "左下"],
                                                ["br", "右下"],
                                            ] as const).map(([key, label]) => (
                                                <button
                                                    key={key}
                                                    type="button"
                                                    onClick={() => setStampCorner(key)}
                                                    className={[
                                                        "rounded border px-2.5 py-1 text-[11px]",
                                                        stampCorner === key
                                                            ? "border-forest bg-forest-tint text-forest"
                                                            : "border-line text-muted hover:border-forest-line",
                                                    ].join(" ")}
                                                >
                                                    {label}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                )}

                                {/*
                                  * 本棚での形。
                                  *
                                  * ★ 作者用ホームの本棚は、縦長で固定していた。
                                  *
                                  *   正方形や横長の表紙を作った人は、
                                  *   左右が落ちて「切ないことになっている」と
                                  *   声が届いた。
                                  *
                                  * ★ 高さは変えない。
                                  *   本ごとに高さが違うと、棚板が波打って見える。
                                  */}
                                <div className="mt-3">
                                    <p className="text-xs text-muted">本棚での形</p>

                                    <div className="mt-1 flex gap-1">
                                        {([
                                            ["tall", "縦長"],
                                            ["wide", "横長"],
                                        ] as const).map(([key, label]) => (
                                            <button
                                                key={key}
                                                type="button"
                                                onClick={() => setCoverShape(key)}
                                                className={[
                                                    "rounded border px-2.5 py-1 text-[11px]",
                                                    coverShape === key
                                                        ? "border-forest bg-forest-tint text-forest"
                                                        : "border-line text-muted hover:border-forest-line",
                                                ].join(" ")}
                                            >
                                                {label}
                                            </button>
                                        ))}
                                    </div>

                                    <p className="mt-1 text-[10.5px] leading-relaxed text-faint">
                                        作者用ホームの本棚で、この作品がどの形で並ぶか。
                                    </p>
                                </div>

                                <p className="mt-1.5 rounded-md border border-amber bg-amber-tint/30 px-2.5 py-2 text-[11px] leading-relaxed text-ink">
                                    <strong>ほかの人の絵を無断で使うことはできません。</strong>
                                    <br />
                                    自分で描いた絵、権利者から許可を得た絵、
                                    または自分で AI に作らせた絵だけを置いてください。
                                    違反が見つかった場合は、画像の削除や作品の非公開などの
                                    対応をとることがあります。
                                </p>

                                {coverError && (
                                    <p className="mt-1.5 text-[11px] text-[var(--color-danger)]">
                                        {coverError}
                                    </p>
                                )}

                                {coverUrl && (
                                    <button
                                        type="button"
                                        onClick={() => setCoverUrl(null)}
                                        className="mt-2 text-[11px] text-faint hover:text-[var(--color-danger)]"
                                    >
                                        表紙を外す
                                    </button>
                                )}
                            </div>
                        </div>
                    </Field>

                    {/*
                      * 本棚での本の色。
                      *
                      * ★ 表紙の絵とは別のもの。
                      *   絵は作品の頁に出る。こちらは棚に並んだときの色。
                      *   絵を用意していない人でも、棚で見分けが付く。
                      *
                      * ★ 色は一覧から選ぶ。自由な色にはしない。
                      *   棚に並んだときに、全体が濁る色が混ざる。
                      *   どれを選んでも棚に馴染む 12 色だけにする。
                      */}
                    <Field label="本棚での本の色">
                        <div className="flex flex-wrap items-center gap-2">
                            <button
                                type="button"
                                onClick={() => setCoverColor(null)}
                                aria-pressed={coverColor === null}
                                className={[
                                    "rounded-md border px-3 py-2 text-[11.5px]",
                                    coverColor === null
                                        ? "border-forest bg-forest-tint/60 text-forest"
                                        : "border-line text-muted hover:border-forest-line",
                                ].join(" ")}
                            >
                                おまかせ
                            </button>

                            {COVERS.map((one, index) => (
                                <button
                                    key={one.base}
                                    type="button"
                                    onClick={() => setCoverColor(index)}
                                    aria-pressed={coverColor === index}
                                    aria-label={`${index + 1}番目の色`}
                                    title={`${index + 1}番目の色`}
                                    style={{ background: one.base }}
                                    className={[
                                        "h-9 w-7 rounded-[3px] border",
                                        coverColor === index
                                            ? "border-forest ring-2 ring-forest/40"
                                            : "border-line hover:border-forest-line",
                                    ].join(" ")}
                                />
                            ))}
                        </div>

                        <p className="mt-1.5 text-[11px] leading-relaxed text-faint">
                            本棚に並んだときの、本の色です。おまかせにすると、
                            題名から決まります（同じ作品はいつも同じ色）。
                        </p>
                    </Field>

                    <Field label="作品の形" htmlFor="info-format">
                        <div className="flex flex-wrap gap-1.5">
                            {(Object.keys(WORK_FORMAT_LABEL) as WorkFormat[]).map(
                                (key) => (
                                    <button
                                        key={key}
                                        type="button"
                                        onClick={() => setFormat(key)}
                                        aria-pressed={format === key}
                                        title={WORK_FORMAT_DESCRIPTION[key]}
                                        className={[
                                            "rounded-full border px-4 py-1.5 text-xs",
                                            format === key
                                                ? "border-forest bg-forest-tint text-forest"
                                                : "border-line text-muted hover:text-ink",
                                        ].join(" ")}
                                    >
                                        {WORK_FORMAT_LABEL[key]}
                                    </button>
                                ),
                            )}
                        </div>
                    </Field>

                    <Field label="タグ" htmlFor="info-tags">
                        <TagInput id="info-tags" tags={tags} onChange={setTags} />
                        {/*
                         * 自分で作れることを書いておく。
                         * 候補から選ぶ欄に見えるので、
                         * 打ち込めると気づかれない。
                         */}
                        <p className="mt-1.5 text-[11px] leading-relaxed text-muted">
                            ※ 候補から選ぶほか、自由に打ち込んで作ることもできます
                            （入力して Enter）。
                        </p>
                    </Field>

                    <Field label="あらすじ" htmlFor="info-summary" error={summaryError}>
                        <textarea
                            id="info-summary"
                            value={summary}
                            rows={5}
                            maxLength={SUMMARY_MAX_LENGTH}
                            onChange={(e) => setSummary(e.target.value)}
                            placeholder="どんな物語か、ひとことでも"
                            className={[
                                "w-full resize-y rounded-md border px-3 py-2 text-sm leading-relaxed outline-none focus:border-forest",
                                isBlank.summary ? blankClass : "border-line",
                            ].join(" ")}
                        />
                        <Counter current={summary.length} max={SUMMARY_MAX_LENGTH} />
                    </Field>
                </div>

                <div className="space-y-5">
                    <Field label="年齢区分">
                        <div className="grid grid-cols-3 gap-2">
                            {(Object.keys(AGE_RATING_LABEL) as AgeRating[]).map((key) => (
                                <button
                                    key={key}
                                    type="button"
                                    onClick={() => {
                                        setAgeRating(key);
                                        /*
                                         * R18 を外したら、BL・GL も外す。
                                         *
                                         * この 2 つは R18 の作品だけのもの。
                                         * 残したまま全年齢の棚に並ぶと、
                                         * 探している人にも探していない人にも
                                         * 意図と違う出方をする。
                                         */
                                        if (
                                            key !== "r18" &&
                                            GENRES_R18_ONLY.includes(genre)
                                        ) {
                                            setGenre("");
                                        }
                                    }}
                                    className={[
                                        "rounded-md border px-3 py-2 text-sm",
                                        ageRating === key
                                            ? "border-forest bg-forest-tint text-forest"
                                            : "border-line text-muted hover:bg-canvas",
                                    ].join(" ")}
                                >
                                    {AGE_RATING_LABEL[key]}
                                </button>
                            ))}
                        </div>
                        <p className="mt-1.5 text-xs text-muted">
                            {AGE_RATING_DESCRIPTION[ageRating]}
                        </p>
                    </Field>

                    {/*
                     * すすめる読む向き。
                     *
                     * 縦書きを前提に組んだ作品もある。
                     * 決めておけば、読む人に印で伝わる。
                     */}
                    <Field label="すすめる読む向き">
                        <div className="grid grid-cols-3 gap-2">
                            {[
                                { key: null, label: "決めない" },
                                { key: "vertical" as const, label: "縦書き" },
                                { key: "horizontal" as const, label: "横書き" },
                            ].map((item) => (
                                <button
                                    key={item.label}
                                    type="button"
                                    onClick={() => setRecommendedMode(item.key)}
                                    className={[
                                        "rounded-md border px-3 py-2 text-sm",
                                        recommendedMode === item.key
                                            ? "border-forest bg-forest-tint text-forest"
                                            : "border-line text-muted hover:bg-canvas",
                                    ].join(" ")}
                                >
                                    {item.label}
                                </button>
                            ))}
                        </div>
                        <p className="mt-1.5 text-xs text-muted">
                            {recommendedMode === null
                                ? "読む人の設定にまかせます。"
                                : recommendedMode === "vertical"
                                  ? "話のページに「縦書き推奨」と出ます。読む人の設定は変わりません。"
                                  : "話のページに「横書き推奨」と出ます。読む人の設定は変わりません。"}
                        </p>
                    </Field>

                    <div className="rounded-md border border-line bg-canvas px-3 py-2.5">
                        <p className="text-xs text-muted">
                            公開するかどうか、連載中か完結かは
                            <span className="text-ink">「公開設定」</span>
                            にまとめました。同じことを2か所で持つと必ず食い違うためです。
                        </p>
                    </div>

                    {/*
                     * AI をどう使ったか。
                     *
                     * 読者が知りたいことなので、はじめから示せるようにする。
                     * 隠すためではなく、申告のため。
                     */}
                    <Field label="AIの使用" htmlFor="info-ai">
                        <ul className="space-y-1.5">
                            {(Object.keys(AI_USAGE_LABEL) as AiUsage[]).map((key) => (
                                <li key={key}>
                                    <button
                                        type="button"
                                        onClick={() => setAiUsage(key)}
                                        aria-pressed={aiUsage === key}
                                        className={[
                                            "w-full rounded-lg border px-3.5 py-2.5 text-left",
                                            aiUsage === key
                                                ? "border-forest bg-forest-tint/50"
                                                : "border-line hover:border-forest-line",
                                        ].join(" ")}
                                    >
                                        <span className="block text-[13px] text-ink">
                                            {AI_USAGE_LABEL[key]}
                                        </span>
                                        <span className="mt-0.5 block text-[11px] leading-relaxed text-muted">
                                            {AI_USAGE_DESCRIPTION[key]}
                                        </span>
                                    </button>
                                </li>
                            ))}
                        </ul>
                    </Field>

                    {/*
                     * 作品を消す。
                     *
                     * 公開の設定とは別物なので、基本情報の一番下に置く。
                     * 「公開をやめる」と「消す」は取り返しが違う。
                     */}
                    <div className="rounded-lg border border-line px-5 py-4">
                        <p className="text-[13px] font-medium text-ink">
                            この作品を消す
                        </p>
                        <p className="mt-1 text-[11px] leading-relaxed text-muted">
                            話も資料も、まとめて消えます。元には戻せません。
                        </p>

                        {isDeleting ? (
                            <div className="mt-3 rounded-lg border border-[var(--color-danger)] bg-[var(--color-danger-tint)] px-4 py-3.5">
                                <p className="text-sm text-ink">
                                    本当に「{work.title || "名前のない作品"}」を消しますか
                                </p>
                                <p className="mt-1.5 text-xs leading-relaxed text-muted">
                                    残しておきたいものがあれば、
                                    先に「インポート・バックアップ」から書き出してください。
                                </p>

                                <div className="mt-3.5 flex gap-2">
                                    <button
                                        type="button"
                                        onClick={() => setIsDeleting(false)}
                                        className="rounded-md border border-line bg-surface px-4 py-2 text-xs text-ink"
                                    >
                                        やめる
                                    </button>
                                    <button
                                        type="button"
                                        onClick={() => void handleDelete()}
                                        className="rounded-md bg-[var(--color-danger)] px-4 py-2 text-xs font-medium text-white hover:opacity-90"
                                    >
                                        消す
                                    </button>
                                </div>
                            </div>
                        ) : (
                            <button
                                type="button"
                                onClick={() => setIsDeleting(true)}
                                className="mt-3 rounded-md border border-[var(--color-danger)] px-4 py-2 text-xs text-[var(--color-danger)] hover:bg-[var(--color-danger-tint)]"
                            >
                                この作品を消す
                            </button>
                        )}
                    </div>
                </div>
            </div>

            <div className="flex flex-wrap items-center justify-end gap-3 border-t border-line px-6 py-4">
                {savedMessage && (
                    <span className="text-sm text-forest">{savedMessage}</span>
                )}

                {/*
                 * 作ったばかりのときは、書きに行く道も出す。
                 * 設定を終えたあと、自分で探させるのは手数が多い。
                 */}
                {isNew && (
                    <Link
                        href={`/workspace/${work.id}`}
                        className="mr-auto text-sm text-muted hover:text-forest"
                    >
                        あとで決めて、先に書く →
                    </Link>
                )}

                <button
                    type="button"
                    onClick={async () => {
                        await handleSave();
                        if (isNew) router.push(`/workspace/${work.id}`);
                    }}
                    disabled={!canSave}
                    className="rounded-md bg-forest px-5 py-2 text-sm text-white hover:bg-forest-dark disabled:cursor-not-allowed disabled:opacity-40"
                >
                    {isNew ? "決めて書きはじめる" : "変更を保存"}
                </button>
            </div>
        </div>
    );
}

/**
 * ============================================================
 * 小さな部品
 * ============================================================
 */

function Field({
    label,
    htmlFor,
    error,
    children,
}: {
    label: string;
    htmlFor?: string;
    error?: string;
    children: React.ReactNode;
}) {
    return (
        <div>
            <label htmlFor={htmlFor} className="block text-sm font-medium text-ink">
                {label}
            </label>
            <div className="mt-1.5">{children}</div>
            {error && <p className="mt-1 text-xs text-[var(--color-amber)]">{error}</p>}
        </div>
    );
}

function Counter({ current, max }: { current: number; max: number }) {
    return (
        <p className="mt-1 text-right text-xs text-faint">
            {current} / {max}
        </p>
    );
}
