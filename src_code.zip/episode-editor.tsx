/**
 * ============================================================
 * 原石航路 Studio
 * EpisodeEditor — 本文の執筆欄
 * ============================================================
 */

"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";

import { useAskText } from "@/hooks/use-ask-text";
import ManuscriptSurface from "@/components/workspace/manuscript-surface";
import { VERSION_AUTO_INTERVAL_MS } from "@/config";
import { useAutosave } from "@/hooks/use-autosave";
import { insertEmphasis, insertRuby } from "@/lib/manuscript/notation";
import { scrollToLine } from "@/lib/manuscript/scroll-to-line";
import { realignIllusts } from "@/lib/illust/realign";
import { getRepository } from "@/lib/repository";
import { countChars, formatNumber, formatTime } from "@/lib/utils/text";
import {
    normalizeForHorizontal,
    normalizeForVertical,
} from "@/lib/utils/vertical-text";
import type { DisplaySettings, Episode } from "@/types";
import { WRITING_MODE_LABEL } from "@/types";
import IllustPlaceSurface from "@/components/workspace/illust-place-surface";
import PickSurface from "@/components/workspace/pick-surface";
import { useRouter } from "next/navigation";

interface Props {
    episode: Episode;
    /**
     * 蛍光ペン。
     * 資料から来たとき、その資料の id が入る。
     */
    pickEntryId?: string | null;
    /**
     * 置き場所を選んでいる挿絵の id。
     *
     * ★ 入っているあいだ、本文は打てない。
     *   蛍光ペンと同じ扱い。
     */
    illustPlacingId?: string | null;
    /** その絵。何を置くのか見せるために渡す */
    illustPlacingUrl?: string | null;
    /** 足す先の資料の名前。何に足しているかを見せる */
    pickEntryName?: string;
    settings: DisplaySettings;
    /** 資料から飛んできたときの行番号。1 から数える */
    jumpToLine?: number | null;
    onJumped?: () => void;
    onSave: (patch: { title: string; body: string }) => Promise<void>;
    /**
     * 作品の題名。書く画面の上に、小さく出す。
     *
     * ★ どの作品を書いているのか、画面の中に無かった。
     *   話を何十も持っていると、開いたときに
     *   どれの続きなのか分からない。
     *
     * ★ ここでは直せない。題名は作品の設定の役目。
     */
    workTitle?: string;
    onToggleWritingMode: () => void;
    onOpenHistory: () => void;
    isHistoryOpen: boolean;
    onOpenMentions: () => void;
    isMentionsOpen: boolean;
    onSelectionChange: (selected: string) => void;
    onOpenProofread: () => void;
    isProofreadOpen: boolean;
    onOpenRead: () => void;
    isReadOpen: boolean;
    /** 推敲パネルからの一括修正を受け取るための橋渡し */
    onRegisterBody: (body: string, apply: (next: string) => void) => void;
    /** 集中モード。一覧やまわりを隠して本文だけにする */
    isFocusMode?: boolean;
    onToggleFocus?: () => void;
}

export default function EpisodeEditor({
    episode,
    workTitle = "",
    pickEntryId = null,
    illustPlacingId = null,
    illustPlacingUrl = null,
    pickEntryName = "この資料",
    settings,
    onSave,
    jumpToLine,
    onJumped,
    onToggleWritingMode,
    onOpenHistory,
    isHistoryOpen,
    onOpenMentions,
    isMentionsOpen,
    onSelectionChange,
    onOpenProofread,
    isProofreadOpen,
    onOpenRead,
    isReadOpen,
    onRegisterBody,
    isFocusMode = false,
    onToggleFocus,
}: Props) {
    /* ルビ・置き換えの問い。ブラウザの prompt は出ない機械がある */
    const { ask, dialog: askDialog } = useAskText();

    const [title, setTitle] = useState(episode.title);
    const [body, setBody] = useState(episode.body);
    /** 縦書き整形の直前の本文。取り消し用に 1 手ぶんだけ持つ */
    const [beforeNormalize, setBeforeNormalize] = useState<string | null>(null);

    /*
     * ほかの道具を開いているか。
     *
     * 狭い画面でだけ使う。
     * 全部並べると 2 段になり、書く場所がそのぶん減る。
     */
    const [isToolsOpen, setIsToolsOpen] = useState(false);

    /*
     * 縮尺。
     *
     * 狭い画面では、決まった大きさだと読みにくい。
     * 全体を見渡したいときは小さく、
     * 直したいときは大きくできるようにする。
     */
    const [zoom, setZoom] = useState(1);
    const [notice, setNotice] = useState("");
    /*
     * 行番号。資料の「第3話 12行目」から場所を探すときに使う。
     * 常に出すと本文の邪魔になるので、切り替えられるようにしておく。
     */
    const [showLineNumbers, setShowLineNumbers] = useState(true);
    /** その行を少しのあいだ光らせる。どこへ来たのか分かるように */
    const [flashLine, setFlashLine] = useState<number | null>(null);
    const surfaceRef = useRef<HTMLDivElement>(null);
    /** 本文の選択位置。ルビを振るときに使う */
    const [range, setRange] = useState<{ start: number; end: number }>({ start: 0, end: 0 });

    /*
     * 蛍光ペン。
     *
     * 資料から「本文から足す」で来たとき、
     * 住所に ?pick=資料のid が付いている。
     *
     * ★ そのあいだは、打ち込む欄をやめて読む形にする。
     *   引用コメントと同じく、文ごとに押せる。
     *
     *   打ち込む欄（textarea）の中には、
     *   文を包む入れ物を置けない。
     *   選んだ範囲から行を割り出す形も試したが、
     *   何が押せるのか分かりにくかった。
     */
    const router = useRouter();

    /*
     * 足す先の名前は、資料の側から渡してもらう。
     * ここで引くと、作品の id が要る。
     */

    const episodeId = episode.id;

    async function addToEntry(text: string, line: number) {
        if (!pickEntryId) return;
        await getRepository().pickMentionLine(pickEntryId, episode.id, line, text);
    }

    /*
     * 別の話に切り替わったときだけ、編集中の値を差し替える。
     *
     * ★ 本文が変わったからといって、書き戻さない。
     *
     *   前は episode.body も見張っていた。
     *   自動保存が終わると、親が話を読み直して episode.body が
     *   新しくなる。するとここが動き、打っている最中の本文を
     *   保存された時点の本文で上書きしていた。
     *
     *   ・保存の往復のあいだに打った字が消える
     *   ・打ち込み欄の中身が入れ替わるので、カーソルが飛ぶ
     *
     *   「改行を調整していると1文字消える」という声は、この形。
     *   改行は1文字なので、往復の隙に入りやすい。
     *
     *   差し替えるのは、開いている話が変わったときだけでよい。
     */
    const loadedIdRef = useRef<string | null>(null);

    useEffect(() => {
        if (loadedIdRef.current === episode.id) return;

        loadedIdRef.current = episode.id;
        setTitle(episode.title);
        setBody(episode.body);
        setBeforeNormalize(null);
    }, [episode.id, episode.title, episode.body]);

    const { state, savedAt } = useAutosave({
        // 2 つの値をまとめて 1 つの文字列として監視する
        value: JSON.stringify({ title, body }),
        onSave: async (serialized) => {
            const parsed = JSON.parse(serialized) as { title: string; body: string };
            await onSave(parsed);
            await maybeCreateVersion();

            /*
             * 挿絵の場所を、本文の直しに追いかけさせる。
             *
             * ★ 場所は「何文目の後ろか」で持っている。
             *   前のほうに文を足すと、後ろの番号がずれる。
             *   置いたときの文を探し直して、番号を付け直す。
             *
             * 失敗しても本文の保存には触らない。
             */
            void realignIllusts(episode.id, parsed.body).catch(() => {});
        },
    });

    /**
     * 自動保存のたびに履歴を作ると版が増えすぎるので、
     * 前回から一定時間あいたときだけ残す。
     */
    const lastVersionAtRef = useRef<number>(0);
    async function maybeCreateVersion() {
        const elapsed = Date.now() - lastVersionAtRef.current;
        if (elapsed < VERSION_AUTO_INTERVAL_MS) return;
        lastVersionAtRef.current = Date.now();
        await getRepository().createVersion(episode.id, "auto");
    }

    function handleNormalize() {
        /*
         * いまの書き方に合わせて直す。
         *
         * 縦書きで打った文を横書きにしても、全角のままだと読みにくい。
         * 逆も同じ。書き方を切り替えたら、揃え直せるようにする。
         */
        const result =
            settings.writing_mode === "vertical"
                ? normalizeForVertical(body)
                : normalizeForHorizontal(body);
        if (result.changeCount === 0) {
            setNotice("直すところはありませんでした");
            window.setTimeout(() => setNotice(""), 2500);
            return;
        }
        setBeforeNormalize(body);
        setBody(result.text);
        setNotice(`${result.changeCount}行を整えました`);
        window.setTimeout(() => setNotice(""), 6000);
    }

    function handleUndoNormalize() {
        if (beforeNormalize === null) return;
        setBody(beforeNormalize);
        setBeforeNormalize(null);
        setNotice("元に戻しました");
        window.setTimeout(() => setNotice(""), 2500);
    }

    // 推敲パネルへ、いまの本文と差し替え口を渡す
    useEffect(() => {
        onRegisterBody(body, setBody);
    }, [body, onRegisterBody]);

    async function handleRuby() {
        if (range.start === range.end) {
            setNotice("ルビを振る文字を選んでください");
            window.setTimeout(() => setNotice(""), 2500);
            return;
        }
        const base = body.slice(range.start, range.end);
        const ruby = await ask(`「${base}」の読みを入れてください`, "");
        if (!ruby?.trim()) return;
        setBody(insertRuby(body, range.start, range.end, ruby.trim()));
    }

    /**
     * カーソルの所に文字を差し込む。
     *
     * 区切り線・一文字下げ・改行で使い回す。
     * 差し込んだあと、その後ろにカーソルを置く。
     * 置かないと、また先頭から探すことになる。
     */
    function insertAt(text: string, addsNewline = true) {
        const area = surfaceRef.current?.querySelector("textarea");
        const at = area?.selectionStart ?? body.length;

        const inserted = addsNewline ? `${text}\n` : text;
        const next = body.slice(0, at) + inserted + body.slice(at);

        setBody(next);

        window.setTimeout(() => {
            if (!area) return;

            const to = at + inserted.length;
            area.focus();
            area.setSelectionRange(to, to);
        }, 0);
    }

    /**
     * 段落の頭を下げる。
     *
     * カーソルの所ではなく、本文の全部に効かせる。
     * 1 行ずつ手で下げるのは、長い話ほど大変になる。
     *
     * 会話文は下げない。
     * 「」『』【】 で始まる行は、そのままのほうが読みやすい。
     * すでに下がっている行も、二重にしない。
     */
    function handleIndent() {
        const OPENERS = ["「", "『", "【"];

        const next = body
            .split("\n")
            .map((line) => {
                const trimmed = line.trimStart();

                if (trimmed === "") return line;
                if (line.startsWith("　")) return line;
                if (OPENERS.some((mark) => trimmed.startsWith(mark))) return line;

                return `　${line}`;
            })
            .join("\n");

        if (next === body) {
            setNotice("下げるところはありませんでした");
            window.setTimeout(() => setNotice(""), 2500);
            return;
        }

        setBeforeNormalize(body);
        setBody(next);

        setNotice("段落の頭を下げました");
        window.setTimeout(() => setNotice(""), 6000);
    }

    /**
     * 置き換える。
     *
     * 何を何に替えるかを 2 度尋ねる。
     * 一度にまとめて替えるので、数を伝える。
     */
    async function handleReplace() {
        const from = await ask("置き換える文字を入れてください", "");
        if (!from) return;

        const to = await ask(`「${from}」を何に替えますか`, "");
        if (to === null) return;

        const count = body.split(from).length - 1;
        if (count === 0) {
            setNotice(`「${from}」は見つかりませんでした`);
            window.setTimeout(() => setNotice(""), 2500);
            return;
        }

        setBeforeNormalize(body);
        setBody(body.split(from).join(to));

        setNotice(`${count}か所を置き換えました`);
        window.setTimeout(() => setNotice(""), 6000);
    }

    function handleEmphasis() {
        if (range.start === range.end) {
            setNotice("傍点をつける文字を選んでください");
            window.setTimeout(() => setNotice(""), 2500);
            return;
        }
        setBody(insertEmphasis(body, range.start, range.end));
    }

    const otherMode = settings.writing_mode === "vertical" ? "horizontal" : "vertical";

    /*
     * 資料から飛んできたら、その行へ動かして選ぶ。
     * 開いただけで場所が分からないのでは、辿れるうちに入らない。
     *
     * ★ 同じ合図では、一度しか動かさない。
     *
     *   前は見張りに onJumped を入れていた。
     *   あれは親が組み直るたびに別物になるので、
     *   組み直るたびに、この中身が走っていた。
     *
     *   「末尾へ寄せる」の合図が残ったまま打つと、
     *   一文字ごとにカーソルが末尾へ飛ぶ。
     *   携帯で「打ちたい所と違う所に入る」のは、これ。
     *
     *   受け取った合図を覚えておき、同じ値では走らせない。
     */
    const jumpedRef = useRef<number | null>(null);

    /* 知らせる先は、見張りに入れずに持つ */
    const onJumpedRef = useRef(onJumped);
    onJumpedRef.current = onJumped;

    useEffect(() => {
        if (!jumpToLine) {
            /* 合図が下りたら、次を受けられるようにする */
            jumpedRef.current = null;
            return;
        }

        if (jumpedRef.current === jumpToLine) return;
        jumpedRef.current = jumpToLine;

        /*
         * 描き終わってから測る。
         * 開いた直後は幅も高さもまだ決まっておらず、
         * その時点で測ると折り返しの位置がずれる。
         */
        const timer = window.setTimeout(() => {
            const area = surfaceRef.current?.querySelector("textarea");
            if (!area) return;

            const result = scrollToLine(area, jumpToLine);

            /*
             * 末尾へ寄せたいだけのとき（開いた直後の「続きから」）は、
             * 光らせず、選ばず、書き足せる形にする。
             *
             * 資料から飛んできたときは「この行だよ」と
             * 示したいので今までどおり光らせる。
             * 行数を超えた指定は、末尾へ寄せる合図として扱う。
             */
            const isTail = jumpToLine >= 999999;

            if (isTail) {
                const end = area.value.length;
                area.setSelectionRange(end, end);
            } else {
                setFlashLine(jumpToLine);
                window.setTimeout(() => setFlashLine(null), 2600);
            }

            void result;
            onJumpedRef.current?.();
        }, 60);

        return () => window.clearTimeout(timer);
    }, [jumpToLine]);

    return (
        <div
            className={[
                /* min-h-0 が無いと、親の高さを超えて膨らむ */
                "flex h-full min-h-0 flex-col overflow-hidden bg-surface",
                // 集中モードは画面の端まで使う。枠と角丸は普段だけ
                isFocusMode ? "" : "rounded-lg border border-line",
            ].join(" ")}
        >
            {/*
             * 上の帯。
             *
             * 狭い画面では 2 段にする。
             * 1 段に詰めると、右のボタンが画面の外へ出る。
             */}
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 border-b border-line px-3 py-2 sm:flex-nowrap sm:gap-2.5 sm:px-5 sm:py-2.5">
                {/*
                  * 題名のまわり。
                  *
                  * ★ 2 行に分け、それぞれに札を付ける。
                  *
                  *   前は「話のタイトル・白書の魔女」と 1 行に並べていた。
                  *   狭い画面で折り返すと、
                  *
                  *     話のタイトル
                  *     ・
                  *     白書の魔女
                  *     エンドロール
                  *
                  *   と縦に落ち、作品の題名が話の題名に見えていた。
                  *
                  * ★ 札は左に揃える。値は右。
                  *   どちらが何の名前かが、線を引かなくても分かる。
                  *
                  * ★ 札は折り返させない。
                  *   折り返すと、また同じ読み違いが起きる。
                  */}
                <div className="grid min-w-0 flex-1 grid-cols-[auto_minmax(0,1fr)] items-center gap-x-2">
                    {workTitle.trim() && (
                        <>
                            <span className="whitespace-nowrap text-[10px] leading-none text-faint">
                                作品タイトル
                            </span>
                            <span className="flex min-w-0 items-center gap-1.5">
                                <span className="min-w-0 truncate text-[11px] leading-none text-muted">
                                    {workTitle}
                                </span>

                                {/*
                                  * 作品の題名を直しに行く道。
                                  *
                                  * ★ ここでは直せないようにしてある。
                                  *   本文を書いている最中に作品そのものが
                                  *   書き換わると、気づかないまま変わる。
                                  *
                                  * ★ 代わりに、直す場所へ送る押し具を置く。
                                  *   直せないことだけ伝えて放り出すと、
                                  *   どこで直すのかを探すことになる。
                                  *
                                  * ★ 同じ窓で開く。
                                  *   別窓にすると、直したあと
                                  *   こちらの画面は古い題名のまま残る。
                                  *   本文は自動で控えてあるので、戻れば続きから書ける。
                                  */}
                                <Link
                                    href={`/workspace/${episode.work_id}/settings`}
                                    className="shrink-0 whitespace-nowrap rounded border border-line px-1.5 py-[1px] text-[10px] leading-none text-muted hover:border-forest-line hover:text-forest"
                                >
                                    変更
                                </Link>
                            </span>
                        </>
                    )}

                    <span className="whitespace-nowrap text-[10px] leading-none text-faint">
                        話のタイトル
                    </span>
                    <input
                        type="text"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        aria-label="話のタイトル"
                        placeholder="話の名前を入れてください"
                        className={[
                            "mt-0.5 w-full border-b bg-transparent text-[14px] font-medium text-ink outline-none focus:border-forest-line",
                            /*
                             * 名前が空のときは、下線で気づかせる。
                             *
                             * 止めはしない。名前は書いているうちに決まることが多く、
                             * 入り口で止めると書き始める気を削ぐ。
                             * 投稿するときには必須にしてある。
                             */
                            title.trim() ? "border-transparent" : "border-amber",
                        ].join(" ")}
                    />
                </div>

                <div className="thin-scroll flex w-full shrink-0 items-center gap-2 overflow-x-auto text-[11px] text-muted lg:w-auto lg:gap-2.5">
                    <SaveIndicator state={state} savedAt={savedAt} />
                    <span>{formatNumber(countChars(body))}文字</span>
                    <button
                        type="button"
                        onClick={onOpenRead}
                        aria-pressed={isReadOpen}
                        className={[
                            "shrink-0 rounded border px-2 py-0.5",
                            isReadOpen
                                ? "border-forest bg-forest-tint text-forest"
                                : "border-line hover:border-forest-line hover:text-forest",
                        ].join(" ")}
                    >
                        通し読み
                    </button>
                    {/*
                     * 推敲は出さない。
                     *
                     * 中身の作り込みが追いついていないので、
                     * 押せる所だけ用意されている状態を避ける。
                     * 仕上がったら、この囲みを外すだけで戻せる。
                     */}
                    {false && (
                        <button
                            type="button"
                            onClick={onOpenProofread}
                            aria-pressed={isProofreadOpen}
                            className={[
                                "shrink-0 rounded border px-2 py-0.5",
                                isProofreadOpen
                                    ? "border-forest bg-forest-tint text-forest"
                                    : "border-line hover:border-forest-line hover:text-forest",
                            ].join(" ")}
                        >
                            推敲
                        </button>
                    )}
                    <button
                        type="button"
                        onClick={onOpenMentions}
                        aria-pressed={isMentionsOpen}
                        className={[
                            "shrink-0 rounded border px-2 py-0.5",
                            isMentionsOpen
                                ? "border-forest bg-forest-tint text-forest"
                                : "border-line hover:border-forest-line hover:text-forest",
                        ].join(" ")}
                    >
                        資料リンク
                    </button>
                    <button
                        type="button"
                        onClick={onOpenHistory}
                        aria-pressed={isHistoryOpen}
                        className={[
                            "shrink-0 rounded border px-2 py-0.5",
                            isHistoryOpen
                                ? "border-forest bg-forest-tint text-forest"
                                : "border-line hover:border-forest-line hover:text-forest",
                        ].join(" ")}
                    >
                        履歴
                    </button>
                </div>
            </div>

            {/*
             * 道具の並び。
             *
             * 狭い画面では「…」に畳む。
             * 全部並べると 2 段になり、書く場所がそのぶん減る。
             *
             * よく使う「縦横」と「行番号」だけは外に出す。
             */}
            <div className="relative flex items-center gap-1.5 border-b border-line bg-canvas px-3 py-1.5 text-[11px] sm:px-5">
                {/*
                 * 大きさ。
                 *
                 * 道具の先頭に置く。
                 * 隅に浮かせると、あることに気づかれない。
                 */}
                <span className="flex shrink-0 items-center rounded border border-line bg-surface lg:hidden">
                    <button
                        type="button"
                        onClick={() => setZoom((now) => Math.max(0.7, now - 0.1))}
                        disabled={zoom <= 0.7}
                        aria-label="小さくする"
                        className="px-2 py-0.5 text-muted hover:text-forest disabled:opacity-35"
                    >
                        −
                    </button>

                    <button
                        type="button"
                        onClick={() => setZoom(1)}
                        title="元の大きさに戻す"
                        className="min-w-[34px] border-x border-line px-1 py-0.5 text-[10px] tabular-nums text-faint hover:text-ink"
                    >
                        {Math.round(zoom * 100)}%
                    </button>

                    <button
                        type="button"
                        onClick={() => setZoom((now) => Math.min(1.6, now + 0.1))}
                        disabled={zoom >= 1.6}
                        aria-label="大きくする"
                        className="px-2 py-0.5 text-muted hover:text-forest disabled:opacity-35"
                    >
                        ＋
                    </button>
                </span>

                <button
                    type="button"
                    onClick={onToggleWritingMode}
                    className="rounded border border-line bg-surface px-2 py-0.5 text-muted hover:border-forest-line hover:text-forest"
                >
                    {WRITING_MODE_LABEL[otherMode]}にする
                </button>

                <button
                    type="button"
                    onClick={() => setShowLineNumbers((show) => !show)}
                    aria-pressed={showLineNumbers}
                    title="10行ごとに行番号を出します"
                    className={[
                        "shrink-0 rounded border px-2 py-0.5",
                        showLineNumbers
                            ? "border-forest bg-forest-tint text-forest"
                            : "border-line bg-surface text-muted hover:border-forest-line hover:text-forest",
                    ].join(" ")}
                >
                    行番号
                </button>

                {/* ここから先は、狭い画面では「…」の中 */}
                <div
                    className={[
                        "flex items-center gap-2",
                        isToolsOpen
                            ? "absolute left-0 right-0 top-full z-20 flex-wrap border-b border-line bg-canvas px-3 py-2 shadow-sm"
                            : "hidden",
                        "lg:static lg:flex lg:border-0 lg:bg-transparent lg:p-0 lg:shadow-none",
                    ].join(" ")}
                >
                <button
                    type="button"
                    onClick={handleNormalize}
                    title={
                        settings.writing_mode === "vertical"
                            ? "半角英数字を全角に、... を …… に直し、段落の頭を字下げします"
                            : "全角英数字を半角に、…… を ... に直します"
                    }
                    className="rounded border border-line bg-surface px-2 py-0.5 text-muted hover:border-forest-line hover:text-forest"
                >
                    {settings.writing_mode === "vertical"
                        ? "縦書き用に整える"
                        : "横書き用に整える"}
                </button>

                {/*
                 * 縦線。
                 *
                 * 左は書き方まわり、右は文字への加工。
                 * 境目が無いと、どこまでが何の仲間か分からない。
                 */}
                <span aria-hidden className="h-4 w-px shrink-0 bg-line" />

                <button
                    type="button"
                    onClick={() => void handleRuby()}
                    title="選んだ文字にルビを振ります（｜親文字《ルビ》）"
                    className="rounded border border-line bg-surface px-2 py-0.5 text-muted hover:border-forest-line hover:text-forest"
                >
                    ルビ
                </button>

                <button
                    type="button"
                    onClick={handleEmphasis}
                    title="選んだ文字に傍点をつけます（《《文字》》）"
                    className="rounded border border-line bg-surface px-2 py-0.5 text-muted hover:border-forest-line hover:text-forest"
                >
                    傍点
                </button>

                {/*
                 * 場面を分ける線。
                 *
                 * 罫線を 12 本つないだもの。
                 * 中黒や星印より、切れ目だと分かりやすい。
                 */}
                <button
                    type="button"
                    onClick={() => insertAt("────────────")}
                    title="場面の切れ目に線を入れます"
                    className="rounded border border-line bg-surface px-2 py-0.5 text-muted hover:border-forest-line hover:text-forest"
                >
                    区切り線
                </button>

                <button
                    type="button"
                    onClick={handleIndent}
                    title="会話文をのぞく段落の頭に、全角の空白を入れます"
                    className="rounded border border-line bg-surface px-2 py-0.5 text-muted hover:border-forest-line hover:text-forest"
                >
                    一文字下げ
                </button>

                {/*
                 * 空の行。
                 *
                 * 間を置きたいときに使う。
                 * 改行を 2 つ入れると、1 行ぶん空く。
                 */}
                <button
                    type="button"
                    onClick={() => insertAt("", true)}
                    title="空の行を入れます"
                    className="rounded border border-line bg-surface px-2 py-0.5 text-muted hover:border-forest-line hover:text-forest"
                >
                    改行
                </button>

                <button
                    type="button"
                    onClick={() => void handleReplace()}
                    title="本文の中の文字を、まとめて置き換えます"
                    className="rounded border border-line bg-surface px-2 py-0.5 text-muted hover:border-forest-line hover:text-forest"
                >
                    置換
                </button>

                {beforeNormalize !== null && (
                    <button
                        type="button"
                        onClick={handleUndoNormalize}
                        className="rounded border border-line bg-surface px-2 py-0.5 text-muted hover:text-ink"
                    >
                        取り消す
                    </button>
                )}

                </div>

                {/* 「…」。狭い画面だけ */}
                <button
                    type="button"
                    onClick={() => setIsToolsOpen(!isToolsOpen)}
                    aria-expanded={isToolsOpen}
                    title="ほかの道具"
                    className={[
                        "ml-auto shrink-0 rounded border px-2 py-0.5 lg:hidden",
                        isToolsOpen
                            ? "border-forest bg-forest-tint text-forest"
                            : "border-line bg-surface text-muted",
                    ].join(" ")}
                >
                    ⋯
                </button>

                {notice && <span className="text-forest">{notice}</span>}

                {/*
                 * 集中モード。
                 *
                 * 隅に浮かべていた頃は、本文やつまみに重なって邪魔だった。
                 * 道具の列の右端に、拡大の印として置く。
                 */}
                {onToggleFocus && (
                    <button
                        type="button"
                        onClick={onToggleFocus}
                        aria-pressed={isFocusMode}
                        title={
                            isFocusMode
                                ? "集中モードを解除します"
                                : "一覧やまわりを隠して、本文だけにします"
                        }
                        className={[
                            "shrink-0 rounded border p-1.5 lg:ml-auto",
                            isFocusMode
                                ? "border-forest bg-forest-tint text-forest"
                                : "border-line bg-surface text-muted hover:border-forest-line hover:text-forest",
                        ].join(" ")}
                    >
                        <FocusIcon on={isFocusMode} />
                    </button>
                )}
            </div>

            {/*
             * 本文。
             *
             * 紙のように見せる。
             * 白い面に影を落とし、周りを少し暗くすると、
             * どこまでが原稿なのかが分かる。
             */}
            <div
                ref={surfaceRef}
                className="relative flex min-h-0 flex-1 overflow-hidden bg-canvas p-0 sm:p-4"
            >
                {/*
                 * 白い紙。
                 *
                 * 高さを必ず決める。
                 *
                 * 以前は広い画面で h-auto にしていた。
                 * 高さの決まっていない親の中では、本文欄の h-full が
                 * 効かずに既定の 2 行ぶんまで縮む。
                 * 横書きにしたとき上の数行しか見えなかったのはこれ。
                 *
                 * 送るのは本文欄。紙は画面いっぱいのまま動かさない。
                 *
                 * 幅は縦書きも横書きも画面いっぱい。
                 * 以前は横書きだけ 820px で止めていたが、
                 * 広く書きたいとの声で外した。
                 */}
                <div className="mx-auto flex h-full min-h-0 w-full flex-col bg-surface shadow-[0_1px_4px_rgba(31,78,107,0.08)] sm:rounded">
                {illustPlacingId ? (
                    /*
                      * 挿絵の置き場所を選んでいるあいだも、打ち込む欄をやめる。
                      * 蛍光ペンと同じ形にして、触り方を揃える。
                      */
                    <IllustPlaceSurface
                        body={body}
                        illustUrl={illustPlacingUrl}
                        onPlace={async (afterSentence, anchorText) => {
                            await getRepository().moveEpisodeIllust(
                                illustPlacingId,
                                afterSentence,
                                anchorText,
                            );
                            router.back();
                        }}
                        onClose={() => router.back()}
                    />
                ) : pickEntryId ? (
                    /*
                      * 蛍光ペンのあいだは、打ち込む欄をやめる。
                      * 文ごとに押せる読む形に差し替える。
                      */
                    <PickSurface
                        body={body}
                        entryName={pickEntryName}
                        onPick={addToEntry}
                        onClose={() => router.back()}
                    />
                ) : (
                <ManuscriptSurface
                    zoom={zoom}
                    settings={settings}
                    value={body}
                    onChange={setBody}
                    showLineNumbers={showLineNumbers}
                    onSelectionChange={onSelectionChange}
                    onRangeChange={setRange}
                    /* 蛍光ペンで来たときだけ、触れた行を丸ごと選ぶ */
                    selectLineOnClick={Boolean(pickEntryId)}
                    placeholder="ここに本文を書きます。"
                />
                )}

                </div>

                {flashLine !== null && (
                    <p className="pointer-events-none absolute right-4 top-3 rounded-full bg-forest px-3 py-1 text-[11px] text-white shadow">
                        {flashLine}行目へ移動しました
                    </p>
                )}
            </div>

            {askDialog}
        </div>
    );
}

function SaveIndicator({ state, savedAt }: { state: string; savedAt: string | null }) {
    if (state === "saving") return <span>保存中</span>;
    if (state === "pending") return <span className="text-faint">未保存の変更</span>;
    /*
     * 保存できたときは青緑にする。
     *
     * 黒のままだと、他の文字に紛れて気づかない。
     * 「保存された」と分かることが、書く人の安心になる。
     */
    if (state === "saved" && savedAt)
        return <span className="text-forest">自動保存済み {formatTime(savedAt)}</span>;
    return <span className="text-faint">自動保存</span>;
}

/** 拡大の印。四隅のかぎ。集中モード中は内向きにして「戻す」を表す */
function FocusIcon({ on = false }: { on?: boolean }) {
    return (
        <svg width="13" height="13" viewBox="0 0 14 14" fill="none" aria-hidden="true">
            {on ? (
                <path
                    d="M5 1v4H1M9 1v4h4M5 13V9H1M9 13V9h4"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                />
            ) : (
                <path
                    d="M1 5V1h4M13 5V1H9M1 9v4h4M13 9v4H9"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                />
            )}
        </svg>
    );
}
